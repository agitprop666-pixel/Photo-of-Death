from __future__ import annotations

import sys, time, math, os, json, zipfile, io
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageChops, ImageOps
import PIL.Image

def resource_path(rel: str) -> str:
    """Resolve a path to a bundled resource. Works in dev (running .py directly)
    AND inside a PyInstaller bundle (where files live under sys._MEIPASS)."""
    base = getattr(sys, '_MEIPASS', None)
    if base:
        return str(Path(base) / rel)
    return str(Path(__file__).parent / rel)

# Safe PIL constants — work across Pillow versions
try:
    _FLIP_LR = PIL.Image.Transpose.FLIP_LEFT_RIGHT
    _FLIP_TB = PIL.Image.Transpose.FLIP_TOP_BOTTOM
except AttributeError:
    _FLIP_LR = PIL.Image.FLIP_LEFT_RIGHT   # type: ignore
    _FLIP_TB = PIL.Image.FLIP_TOP_BOTTOM   # type: ignore
try:
    _BICUBIC = PIL.Image.Resampling.BICUBIC
    _LANCZOS = PIL.Image.Resampling.LANCZOS
except AttributeError:
    _BICUBIC = PIL.Image.BICUBIC           # type: ignore
    _LANCZOS = PIL.Image.ANTIALIAS         # type: ignore

from PyQt6.QtCore import (
    Qt, QTimer, QPoint, QRect, QSize, QRectF, QPointF, pyqtSignal, QByteArray
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPixmap, QImage, QPen, QIcon,
    QAction, QKeySequence, QPainterPath, QFontMetrics, QFontDatabase
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QSplashScreen, QLabel, QScrollArea,
    QStatusBar, QMenu, QFileDialog, QColorDialog,
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout,
    QSpinBox, QDoubleSpinBox, QSlider, QCheckBox, QComboBox, QPushButton,
    QAbstractButton, QMessageBox, QInputDialog, QButtonGroup, QSizePolicy,
    QFrame, QMdiArea, QMdiSubWindow
)

# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────
APP_NAME      = "Photo of Death"
APP_VERSION   = "1.0"
ORG_NAME      = "Death's Head Software"
MAX_HISTORY   = 20
MAX_LAYERS    = 20
BRUSH_SIZES   = [1, 3, 5, 10, 20, 30, 50]
WAND_TOL_LOW  = 16
WAND_TOL_MED  = 32
WAND_TOL_HIGH = 64

from enum import Enum, auto
class Tool(Enum):
    MARQUEE_RECT    = auto()
    MARQUEE_ELLIPSE = auto()
    LASSO           = auto()
    MAGIC_WAND      = auto()
    MOVE            = auto()
    CROP            = auto()
    EYEDROPPER      = auto()
    PAINT_BUCKET    = auto()
    GRADIENT        = auto()
    BRUSH           = auto()
    AIRBRUSH        = auto()
    PENCIL          = auto()
    ERASER          = auto()
    ZOOM_IN         = auto()
    ZOOM_OUT        = auto()

# ─────────────────────────────────────────────────────────────
# PIL <-> QImage
# ─────────────────────────────────────────────────────────────
def pil_to_qimage(img: PIL.Image.Image) -> QImage:
    img = img.convert("RGBA")
    data = img.tobytes("raw", "RGBA")
    return QImage(data, img.width, img.height,
                  QImage.Format.Format_RGBA8888).copy()

def qimage_to_pil(qimg: QImage) -> PIL.Image.Image:
    """Convert a QImage to a PIL RGBA image. Used when adjustments/transforms
    need to operate on a floating text overlay (which is a QImage)."""
    fmt = qimg.convertToFormat(QImage.Format.Format_RGBA8888)
    w, h = fmt.width(), fmt.height()
    ptr = fmt.bits(); ptr.setsize(w * h * 4)
    return PIL.Image.frombytes("RGBA", (w, h), bytes(ptr))

def mask_arr(mask, w, h):
    if mask is None: return None
    return np.array(mask.convert("L")) > 128

# ─────────────────────────────────────────────────────────────
# PrecisionSlider — Ctrl=fine mode, double-click=reset
# ─────────────────────────────────────────────────────────────
class PrecisionSlider(QSlider):
    """QSlider with Ctrl-key fine-mode (÷10 step) and double-click reset."""
    def __init__(self, orientation, default=0, parent=None):
        super().__init__(orientation, parent)
        self._default = default
        self._base_step = 1

    def setDefault(self, v): self._default = v

    def keyPressEvent(self, e):
        # Ctrl held: single-unit steps regardless of page step
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            if e.key() in (Qt.Key.Key_Left, Qt.Key.Key_Down):
                self.setValue(self.value() - 1); return
            if e.key() in (Qt.Key.Key_Right, Qt.Key.Key_Up):
                self.setValue(self.value() + 1); return
        super().keyPressEvent(e)

    def wheelEvent(self, e):
        # Ctrl held: fine wheel (1 unit), normal: 3 units
        step = 1 if e.modifiers() & Qt.KeyboardModifier.ControlModifier else 3
        delta = e.angleDelta().y()
        self.setValue(self.value() + (step if delta > 0 else -step))
        e.accept()

    def mouseDoubleClickEvent(self, e):
        self.setValue(self._default)

    def mousePressEvent(self, e):
        # Ctrl+click on the groove → fine drag (set singleStep=1 temporarily)
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.setSingleStep(1)
        else:
            self.setSingleStep(self._base_step)
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.setSingleStep(1)
        else:
            self.setSingleStep(self._base_step)
        super().mouseMoveEvent(e)


class Layer:
    _ctr = 0
    def __init__(self, w, h, name="", fill=(0,0,0,0)):
        Layer._ctr += 1
        self.name    = name or f"Layer {Layer._ctr}"
        self.image   = PIL.Image.new("RGBA", (w, h), fill)
        self.visible = True
        self.opacity = 1.0
        self._thumb_cache: QPixmap | None = None  # invalidated by _invalidate_thumb()
    def _invalidate_thumb(self): self._thumb_cache = None
    def copy(self):
        l = Layer.__new__(Layer)
        l.name = self.name; l.image = self.image.copy()
        l.visible = self.visible; l.opacity = self.opacity
        l._thumb_cache = None
        return l

class Document:
    def __init__(self, w, h, color_space="RGB"):
        self.w = w; self.h = h
        self.color_space = color_space  # "RGB" or "CMYK"
        self.layers: list[Layer] = []
        self.active: int = 0
        # Linked-layer set: layer indices that adjustments apply to.
        # Empty/single = adjustments apply to the active layer only (no linking).
        # Multiple = adjustments apply to every index in the set.
        self.linked: set[int] = set()
    def composite(self):
        result = PIL.Image.new("RGBA", (self.w, self.h), (0,0,0,0))
        for l in self.layers:
            if not l.visible: continue
            img = l.image
            if img.size != (self.w, self.h):
                tmp = PIL.Image.new("RGBA", (self.w, self.h), (0,0,0,0))
                paste = img.crop((0, 0, min(img.width,self.w), min(img.height,self.h)))
                tmp.paste(paste, (0,0)); img = tmp
            if l.opacity < 1.0:
                # Scale alpha channel by opacity without touching RGB
                arr = np.array(img, dtype=np.float32)
                arr[:,:,3] = np.clip(arr[:,:,3] * l.opacity, 0, 255)
                img = PIL.Image.fromarray(arr.astype(np.uint8), "RGBA")
            result = PIL.Image.alpha_composite(result, img)
        return result
    @property
    def active_layer(self):
        return self.layers[self.active] if 0 <= self.active < len(self.layers) else None
    def snapshot(self): return [l.copy() for l in self.layers]
    def restore(self, snap):
        self.layers = [l.copy() for l in snap]
        self.active = min(self.active, len(self.layers)-1)

# ─────────────────────────────────────────────────────────────
# Splash
# ─────────────────────────────────────────────────────────────
def create_splash():
    try:
        sp = Path(__file__).parent / "splash.png"
        if sp.exists():
            px = QPixmap(str(sp))
            if px.isNull(): px = QPixmap(800,600); px.fill(QColor(20,20,20))
            if px.width()!=800 or px.height()!=600:
                px = px.scaled(800,600,Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
            p = QPainter(px)
            p.setPen(QColor(255,255,255))
            p.setFont(QFont("Courier",38,QFont.Weight.Bold))
            tr=px.rect(); tr.setTop(40); tr.setBottom(100)
            p.drawText(tr,Qt.AlignmentFlag.AlignCenter|Qt.AlignmentFlag.AlignVCenter,APP_NAME)
            p.setFont(QFont("Courier",14,QFont.Weight.Bold))
            fr=px.rect(); fr.setTop(px.height()-100); fr.setBottom(px.height()-50)
            p.drawText(fr,Qt.AlignmentFlag.AlignCenter|Qt.AlignmentFlag.AlignVCenter,ORG_NAME)
            p.end()
        else:
            px = QPixmap(800,600); px.fill(QColor(20,20,20))
            p = QPainter(px); p.setPen(QColor(255,255,255))
            p.setFont(QFont("Courier",38,QFont.Weight.Bold))
            tr=px.rect(); tr.setTop(40); tr.setBottom(100)
            p.drawText(tr,Qt.AlignmentFlag.AlignCenter|Qt.AlignmentFlag.AlignVCenter,APP_NAME)
            p.setFont(QFont("Courier",14))
            skull=["        ___________      ","       /           \\    ",
                   "      |  O       O  |   ","      |      ^      |   ",
                   "      |   \\_____/   |   ","       \\_         _/    ",
                   "         |_______|      "]
            for i,ln in enumerate(skull): p.drawText(250,250+i*25,ln)
            p.setFont(QFont("Courier",14,QFont.Weight.Bold))
            fr=px.rect(); fr.setTop(px.height()-50); fr.setBottom(px.height())
            p.drawText(fr,Qt.AlignmentFlag.AlignCenter|Qt.AlignmentFlag.AlignVCenter,ORG_NAME)
            p.end()
        return QSplashScreen(px, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:",e); return None

# ─────────────────────────────────────────────────────────────
# Dialogs
# ─────────────────────────────────────────────────────────────
class NewImageDialog(QDialog):
    DPI_PRESETS = [72, 96, 150, 200, 300, 600]

    def __init__(self, dpi=72, parent=None):
        super().__init__(parent); self.setWindowTitle("New Image"); self.setFixedSize(360,320)
        l=QFormLayout(self)
        self.ws=QSpinBox(); self.ws.setRange(1,16000); self.ws.setValue(int(8.5*dpi))
        self.hs=QSpinBox(); self.hs.setRange(1,16000); self.hs.setValue(int(11*dpi))
        l.addRow("Width (px):",self.ws); l.addRow("Height (px):",self.hs)
        # DPI with presets
        dpi_row=QHBoxLayout()
        self.rs=QSpinBox(); self.rs.setRange(1,2400); self.rs.setValue(dpi)
        dpi_row.addWidget(self.rs)
        self.dpi_combo=QComboBox()
        for d in self.DPI_PRESETS: self.dpi_combo.addItem(f"{d} ppi",d)
        # Set combo to match current DPI
        idx=self.dpi_combo.findData(dpi)
        if idx>=0: self.dpi_combo.setCurrentIndex(idx)
        self.dpi_combo.currentIndexChanged.connect(
            lambda i: self.rs.setValue(self.dpi_combo.currentData()))
        dpi_row.addWidget(self.dpi_combo)
        l.addRow("Resolution:",dpi_row)
        # Color space
        self.cs=QComboBox(); self.cs.addItems(["RGB","CMYK"])
        l.addRow("Color Space:",self.cs)
        self.bg=QComboBox(); self.bg.addItems(["White","Black","Transparent"])
        l.addRow("Background:",self.bg)
        self.rs.valueChanged.connect(self._dpi_changed)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)
    def _dpi_changed(self, dpi):
        self.ws.setValue(int(8.5*dpi)); self.hs.setValue(int(11*dpi))
    def values(self):
        m={"White":(255,255,255,255),"Black":(0,0,0,255),"Transparent":(0,0,0,0)}
        return self.ws.value(),self.hs.value(),self.rs.value(),m[self.bg.currentText()],self.cs.currentText()

class ImageSizeDialog(QDialog):
    DPI_PRESETS = [72, 96, 150, 200, 300, 600]

    def __init__(self, w, h, dpi=72, color_space="RGB", parent=None):
        super().__init__(parent); self.setWindowTitle("Image Size"); self.setMinimumWidth(380)
        self.ow=w; self.oh=h; self._lk=False
        l=QFormLayout(self)
        # Pixel dimensions
        self.wp=QSpinBox(); self.wp.setRange(1,16000); self.wp.setValue(w)
        self.hp=QSpinBox(); self.hp.setRange(1,16000); self.hp.setValue(h)
        self.wpc=QDoubleSpinBox(); self.wpc.setRange(.1,1000); self.wpc.setValue(100); self.wpc.setSuffix("%")
        self.hpc=QDoubleSpinBox(); self.hpc.setRange(.1,1000); self.hpc.setValue(100); self.hpc.setSuffix("%")
        self.con=QCheckBox("Constrain Proportions"); self.con.setChecked(True)
        l.addRow("Width (px):",self.wp); l.addRow("Height (px):",self.hp)
        l.addRow("Width %:",self.wpc); l.addRow("Height %:",self.hpc)
        l.addRow(self.con)
        # DPI with presets
        dpi_row=QHBoxLayout()
        self.dpi_spin=QSpinBox(); self.dpi_spin.setRange(1,2400); self.dpi_spin.setValue(dpi)
        dpi_row.addWidget(self.dpi_spin)
        self.dpi_combo=QComboBox()
        for d in self.DPI_PRESETS: self.dpi_combo.addItem(f"{d} ppi",d)
        idx=self.dpi_combo.findData(dpi)
        if idx>=0: self.dpi_combo.setCurrentIndex(idx)
        # Two-way binding: combo -> spin and spin -> combo
        self._dpi_lock = False
        def combo_to_spin(i):
            if self._dpi_lock: return
            self._dpi_lock = True
            self.dpi_spin.setValue(self.dpi_combo.currentData())
            self._dpi_lock = False
        def spin_to_combo(v):
            if self._dpi_lock: return
            self._dpi_lock = True
            idx = self.dpi_combo.findData(v)
            if idx >= 0:
                self.dpi_combo.setCurrentIndex(idx)
            else:
                # Custom value - set combo to index -1 (no selection)
                self.dpi_combo.setCurrentIndex(-1)
            self._dpi_lock = False
        self.dpi_combo.currentIndexChanged.connect(combo_to_spin)
        self.dpi_spin.valueChanged.connect(spin_to_combo)
        dpi_row.addWidget(self.dpi_combo)
        l.addRow("Resolution:",dpi_row)
        # Color space
        self.cs=QComboBox(); self.cs.addItems(["RGB","CMYK"])
        cs_idx=self.cs.findText(color_space)
        if cs_idx>=0: self.cs.setCurrentIndex(cs_idx)
        l.addRow("Color Space:",self.cs)
        # Proportional linking
        self.wp.valueChanged.connect(self._pw); self.hp.valueChanged.connect(self._ph)
        self.wpc.valueChanged.connect(self._ppw); self.hpc.valueChanged.connect(self._pph)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)
    def _pw(self,v):
        if self._lk: return
        self._lk=True; self.wpc.setValue(v/self.ow*100)
        if self.con.isChecked():
            nh=max(1,int(self.oh*v/self.ow)); self.hp.setValue(nh); self.hpc.setValue(nh/self.oh*100)
        self._lk=False
    def _ph(self,v):
        if self._lk: return
        self._lk=True; self.hpc.setValue(v/self.oh*100)
        if self.con.isChecked():
            nw=max(1,int(self.ow*v/self.oh)); self.wp.setValue(nw); self.wpc.setValue(nw/self.ow*100)
        self._lk=False
    def _ppw(self,v):
        if self._lk: return
        self._lk=True; nw=max(1,int(self.ow*v/100)); self.wp.setValue(nw)
        if self.con.isChecked(): nh=max(1,int(self.oh*v/100)); self.hp.setValue(nh); self.hpc.setValue(v)
        self._lk=False
    def _pph(self,v):
        if self._lk: return
        self._lk=True; nh=max(1,int(self.oh*v/100)); self.hp.setValue(nh)
        if self.con.isChecked(): nw=max(1,int(self.ow*v/100)); self.wp.setValue(nw); self.wpc.setValue(v)
        self._lk=False
    def values(self):
        return self.wp.value(), self.hp.value(), self.dpi_spin.value(), self.cs.currentText()

class CanvasSizeDialog(QDialog):
    def __init__(self,w,h,parent=None):
        super().__init__(parent); self.setWindowTitle("Canvas Size")
        l=QFormLayout(self)
        self.ws=QSpinBox(); self.ws.setRange(1,16000); self.ws.setValue(w)
        self.hs=QSpinBox(); self.hs.setRange(1,16000); self.hs.setValue(h)
        l.addRow("Width (px):",self.ws); l.addRow("Height (px):",self.hs)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)
    def values(self): return self.ws.value(),self.hs.value()

class RotateDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle("Rotate")
        l=QFormLayout(self)
        self.ang=QDoubleSpinBox(); self.ang.setRange(-360,360); self.ang.setValue(0); self.ang.setSuffix("°")
        self.dir=QComboBox(); self.dir.addItems(["CW","CCW"])
        l.addRow("Angle:",self.ang); l.addRow("Direction:",self.dir)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)
    def values(self):
        a=self.ang.value(); return -a if self.dir.currentText()=="CCW" else a

class BrightnessContrastDialog(QDialog):
    preview_changed = pyqtSignal(object)

    def __init__(self, src_img, parent=None):
        super().__init__(parent); self.setWindowTitle("Brightness / Contrast")
        self._src = src_img.copy()
        self._ptimer = QTimer(self); self._ptimer.setSingleShot(True)
        self._ptimer.setInterval(120); self._ptimer.timeout.connect(self._fire)
        l=QFormLayout(self)
        self.b = PrecisionSlider(Qt.Orientation.Horizontal, default=0)
        self.b.setRange(-100,100); self.b.setValue(0); self.b.setPageStep(5)
        self.c = PrecisionSlider(Qt.Orientation.Horizontal, default=0)
        self.c.setRange(-100,100); self.c.setValue(0); self.c.setPageStep(5)
        self.bl=QLabel("0"); self.cl=QLabel("0")
        self.b.valueChanged.connect(lambda v:(self.bl.setText(str(v)), self._ptimer.start()))
        self.c.valueChanged.connect(lambda v:(self.cl.setText(str(v)), self._ptimer.start()))
        br=QHBoxLayout(); br.addWidget(self.b); br.addWidget(self.bl)
        cr=QHBoxLayout(); cr.addWidget(self.c); cr.addWidget(self.cl)
        l.addRow("Brightness:",br); l.addRow("Contrast:",cr)
        hint=QLabel("Ctrl+drag = fine  •  double-click = reset")
        hint.setStyleSheet("color:#666;font-size:9px;"); l.addRow(hint)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)

    def _fire(self): self.preview_changed.emit(self._apply())

    def _apply(self):
        b,c = self.b.value(), self.c.value()
        arr=np.array(self._src,dtype=np.float32)
        rgb=arr[:,:,:3]; alpha=arr[:,:,3:4]
        rgb=rgb+b*2.55
        if c!=0:
            f=(259*(c+255))/(255*(259-c)); rgb=f*(rgb-128)+128
        out=np.concatenate([np.clip(rgb,0,255),alpha],axis=2).astype(np.uint8)
        return PIL.Image.fromarray(out,"RGBA")

    def result_image(self): return self._apply()
    def values(self): return self.b.value(), self.c.value()

class HueSaturationDialog(QDialog):
    preview_changed = pyqtSignal(object)

    def __init__(self, src_img, parent=None):
        super().__init__(parent); self.setWindowTitle("Hue / Saturation")
        self._src = src_img.copy()
        self._ptimer = QTimer(self); self._ptimer.setSingleShot(True)
        self._ptimer.setInterval(150); self._ptimer.timeout.connect(self._fire)
        l=QFormLayout(self)
        self.h  = PrecisionSlider(Qt.Orientation.Horizontal, default=0)
        self.h.setRange(-180,180); self.h.setValue(0); self.h.setPageStep(10)
        self.s  = PrecisionSlider(Qt.Orientation.Horizontal, default=0)
        self.s.setRange(-100,100); self.s.setValue(0); self.s.setPageStep(5)
        self.lv = PrecisionSlider(Qt.Orientation.Horizontal, default=0)
        self.lv.setRange(-100,100); self.lv.setValue(0); self.lv.setPageStep(5)
        self.hl=QLabel("0"); self.sl=QLabel("0"); self.ll=QLabel("0")
        self.col=QCheckBox("Colorize")
        self.h.valueChanged.connect(lambda v:(self.hl.setText(str(v)), self._ptimer.start()))
        self.s.valueChanged.connect(lambda v:(self.sl.setText(str(v)), self._ptimer.start()))
        self.lv.valueChanged.connect(lambda v:(self.ll.setText(str(v)), self._ptimer.start()))
        self.col.stateChanged.connect(lambda _: self._ptimer.start())
        hr=QHBoxLayout(); hr.addWidget(self.h); hr.addWidget(self.hl)
        sr=QHBoxLayout(); sr.addWidget(self.s); sr.addWidget(self.sl)
        lr=QHBoxLayout(); lr.addWidget(self.lv); lr.addWidget(self.ll)
        l.addRow("Hue:",hr); l.addRow("Saturation:",sr)
        l.addRow("Lightness:",lr); l.addRow(self.col)
        hint=QLabel("Ctrl+drag = fine  •  double-click = reset")
        hint.setStyleSheet("color:#666;font-size:9px;"); l.addRow(hint)
        row=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(ca); l.addRow(row)

    def _fire(self): self.preview_changed.emit(self._apply())

    def _apply(self):
        hs,ss,ls,colorize = self.h.value(),self.s.value(),self.lv.value(),self.col.isChecked()
        arr=np.array(self._src,dtype=np.float32)/255.0
        rgb=arr[:,:,:3]; alpha=arr[:,:,3]
        r,g,b2=rgb[...,0],rgb[...,1],rgb[...,2]
        cmax=np.maximum(np.maximum(r,g),b2); cmin=np.minimum(np.minimum(r,g),b2); delta=cmax-cmin
        ll=(cmax+cmin)/2.0
        sat=np.where(delta==0,0.0,np.where(ll<0.5,delta/(cmax+cmin+1e-8),delta/(2.0-cmax-cmin+1e-8)))
        hue=np.zeros_like(r)
        mr=(cmax==r)&(delta!=0); mg=(cmax==g)&(delta!=0); mb=(cmax==b2)&(delta!=0)
        hue[mr]=((g[mr]-b2[mr])/(delta[mr]+1e-8))%6
        hue[mg]=(b2[mg]-r[mg])/(delta[mg]+1e-8)+2
        hue[mb]=(r[mb]-g[mb])/(delta[mb]+1e-8)+4
        hue=hue/6.0
        if colorize:
            hue=np.full_like(hue,(hs%360)/360.0)
            sat=np.clip(np.full_like(sat,max(0,ss)/100.0),0,1)
        else:
            hue=(hue+hs/360.0)%1.0; sat=np.clip(sat+ss/100.0,0,1)
        ll=np.clip(ll+ls/100.0,0,1)
        def ch(h,l,s,n):
            k=(n+h*12)%12; a=s*np.minimum(l,1-l)
            return l-a*np.maximum(-1.0,np.minimum(np.minimum(k-3,9-k),1.0))
        out=np.stack([ch(hue,ll,sat,0),ch(hue,ll,sat,8),ch(hue,ll,sat,4),alpha],axis=2)
        return PIL.Image.fromarray(np.clip(out*255,0,255).astype(np.uint8),"RGBA")

    def result_image(self): return self._apply()
    def values(self): return self.h.value(),self.s.value(),self.lv.value(),self.col.isChecked()

class TextDialog(QDialog):
    def __init__(self,fg:QColor,parent=None):
        super().__init__(parent); self.setWindowTitle("Place Text"); self.setMinimumWidth(420)
        self._color=QColor(fg); l=QVBoxLayout(self)
        self.txt=QComboBox(); self.txt.setEditable(True)
        self.txt.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.txt.lineEdit().setPlaceholderText("Enter text…")
        l.addWidget(QLabel("Text:")); l.addWidget(self.txt)
        fr=QHBoxLayout(); self.fc=QComboBox(); self.fc.setMaxVisibleItems(20)
        for fam in sorted(QFontDatabase.families()): self.fc.addItem(fam)
        for d in ("Arial","Helvetica","Segoe UI","DejaVu Sans"):
            idx=self.fc.findText(d)
            if idx>=0: self.fc.setCurrentIndex(idx); break
        fr.addWidget(QLabel("Font:")); fr.addWidget(self.fc,1); l.addLayout(fr)
        sr=QHBoxLayout()
        self.sz=QSpinBox(); self.sz.setRange(4,999); self.sz.setValue(24)
        self.bo=QCheckBox("Bold"); self.it=QCheckBox("Italic"); self.un=QCheckBox("Underline")
        sr.addWidget(QLabel("Size:")); sr.addWidget(self.sz)
        sr.addSpacing(8); sr.addWidget(self.bo); sr.addWidget(self.it); sr.addWidget(self.un)
        sr.addStretch(); l.addLayout(sr)
        ar=QHBoxLayout(); self.al=QComboBox(); self.al.addItems(["Left","Center","Right"])
        ar.addWidget(QLabel("Align:")); ar.addWidget(self.al)
        ar.addSpacing(12)
        self.orient=QComboBox(); self.orient.addItems(["Horizontal","Vertical"])
        ar.addWidget(QLabel("Orient:")); ar.addWidget(self.orient)
        ar.addStretch(); l.addLayout(ar)
        cr=QHBoxLayout(); self.cb=QPushButton(); self.cb.setFixedSize(40,24)
        self._upd_cb(); self.cb.clicked.connect(self._pick)
        cr.addWidget(QLabel("Color:")); cr.addWidget(self.cb); cr.addStretch(); l.addLayout(cr)
        self.prev=QLabel("Preview"); self.prev.setFixedHeight(60)
        self.prev.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.prev.setStyleSheet("background:#1a1a1e;border:1px solid #555;")
        l.addWidget(self.prev)
        self.fc.currentTextChanged.connect(self._upd_prev)
        self.sz.valueChanged.connect(self._upd_prev)
        self.bo.stateChanged.connect(self._upd_prev)
        self.it.stateChanged.connect(self._upd_prev)
        self.un.stateChanged.connect(self._upd_prev)
        self.txt.currentTextChanged.connect(self._upd_prev)
        self._upd_prev()
        br=QHBoxLayout(); ok=QPushButton("OK"); ok.clicked.connect(self.accept)
        ca=QPushButton("Cancel"); ca.clicked.connect(self.reject)
        br.addStretch(); br.addWidget(ok); br.addWidget(ca); l.addLayout(br)
    def _upd_cb(self):
        self.cb.setStyleSheet(f"background:{self._color.name()};border:1px solid #888;")
    def _pick(self):
        c=QColorDialog.getColor(self._color, self.window(), "Text Color",
            QColorDialog.ColorDialogOption.ShowAlphaChannel)
        if c.isValid(): self._color=c; self._upd_cb(); self._upd_prev()
    def _font(self):
        f=QFont(self.fc.currentText(),self.sz.value())
        f.setBold(self.bo.isChecked()); f.setItalic(self.it.isChecked())
        f.setUnderline(self.un.isChecked()); return f
    def _upd_prev(self):
        t=self.txt.currentText() or "Sample Text"; f=self._font()
        self.prev.setFont(f); self.prev.setText(t)
        self.prev.setStyleSheet(
            f"background:#1a1a1e;border:1px solid #555;color:{self._color.name()};")
    def values(self):
        m={"Left":Qt.AlignmentFlag.AlignLeft,"Center":Qt.AlignmentFlag.AlignHCenter,
           "Right":Qt.AlignmentFlag.AlignRight}
        return {"text":self.txt.currentText(),"font":self._font(),
                "color":QColor(self._color),"align":m[self.al.currentText()],
                "orientation":self.orient.currentText()}

# ─────────────────────────────────────────────────────────────
# Floating text toolbar
# ─────────────────────────────────────────────────────────────
class FloatingTextBar(QWidget):
    flatten_clicked=pyqtSignal(); cancel_clicked=pyqtSignal()
    def __init__(self,parent=None):
        super().__init__(parent,Qt.WindowType.Tool|Qt.WindowType.WindowStaysOnTopHint)
        self.setWindowTitle("Text"); self.setFixedSize(260,44)
        l=QHBoxLayout(self); l.setContentsMargins(6,6,6,6); l.setSpacing(8)
        self.fb=QPushButton("⬇  Flatten"); self.fb.setFixedHeight(28)
        self.fb.setStyleSheet("QPushButton{background:#3a7bd5;color:white;border-radius:4px;font-weight:bold;}"
                              "QPushButton:hover{background:#2a5bb5;}")
        self.cb=QPushButton("✕  Cancel"); self.cb.setFixedHeight(28)
        self.cb.setStyleSheet("QPushButton{background:#c0392b;color:white;border-radius:4px;font-weight:bold;}"
                              "QPushButton:hover{background:#a93226;}")
        l.addWidget(self.fb); l.addWidget(self.cb)
        self.fb.clicked.connect(self.flatten_clicked); self.cb.clicked.connect(self.cancel_clicked)

# ─────────────────────────────────────────────────────────────
# SVG icons + tool button
# ─────────────────────────────────────────────────────────────
SVGS={
    Tool.MARQUEE_RECT:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" fill="none" stroke="white" stroke-width="1.8" stroke-dasharray="3,2"/></svg>',
    Tool.MARQUEE_ELLIPSE:'<svg viewBox="0 0 24 24"><ellipse cx="12" cy="12" rx="9" ry="9" fill="none" stroke="white" stroke-width="1.8" stroke-dasharray="3,2"/></svg>',
    Tool.LASSO:'<svg viewBox="0 0 24 24"><path d="M12 4C6 4 3 8 3 12C3 17 7 20 12 20C17 20 21 17 21 12C21 9 19 6 16 5" fill="none" stroke="white" stroke-width="1.8" stroke-dasharray="3,2" stroke-linecap="round"/></svg>',
    Tool.MAGIC_WAND:'<svg viewBox="0 0 24 24"><line x1="14" y1="10" x2="21" y2="21" stroke="white" stroke-width="2.2" stroke-linecap="round"/><circle cx="10" cy="7" r="1.2" fill="white"/><line x1="10" y1="2" x2="10" y2="4" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="10" y1="10" x2="10" y2="12" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="5" y1="7" x2="7" y2="7" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="13" y1="7" x2="15" y2="7" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>',
    Tool.MOVE:'<svg viewBox="0 0 24 24"><path d="M12 2L9 6L11 6L11 11L6 11L6 9L2 12L6 15L6 13L11 13L11 18L9 18L12 22L15 18L13 18L13 13L18 13L18 15L22 12L18 9L18 11L13 11L13 6L15 6Z" fill="white"/></svg>',
    Tool.EYEDROPPER:'<svg viewBox="0 0 24 24"><path d="M20 4C18 2 15 2 13 4L11 6L9 4L4 9L6 11L4 20L8 20L11 13L13 11L15 13L20 8C22 6 22 6 20 4Z" fill="none" stroke="white" stroke-width="1.6" stroke-linejoin="round"/><circle cx="5.5" cy="19.5" r="2" fill="white"/></svg>',
    Tool.PAINT_BUCKET:'<svg viewBox="0 0 24 24"><path d="M3 17L9 3L15 17Z" fill="none" stroke="white" stroke-width="1.8" stroke-linejoin="round"/><line x1="4.5" y1="13" x2="13.5" y2="13" stroke="white" stroke-width="1.8"/><circle cx="19" cy="18" r="3" fill="none" stroke="white" stroke-width="1.8"/><line x1="15" y1="10" x2="19" y2="14" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>',
    Tool.GRADIENT:'<svg viewBox="0 0 24 24"><defs><linearGradient id="g"><stop offset="0" stop-color="white" stop-opacity="1"/><stop offset="1" stop-color="white" stop-opacity="0.1"/></linearGradient></defs><rect x="3" y="6" width="18" height="12" fill="url(#g)" rx="1"/><line x1="3" y1="6" x2="3" y2="18" stroke="white" stroke-width="1.5"/></svg>',
    Tool.BRUSH:'<svg viewBox="0 0 24 24"><path d="M20 3L17 6L7 16C5 18 3 18 3 21C6 21 6 19 8 17L18 7Z" fill="white" stroke-linejoin="round"/></svg>',
    Tool.PENCIL:'<svg viewBox="0 0 24 24"><path d="M17 3L21 7L8 20L3 21L4 16Z" fill="none" stroke="white" stroke-width="1.8" stroke-linejoin="round"/><line x1="15" y1="5" x2="19" y2="9" stroke="white" stroke-width="1.8"/></svg>',
    Tool.ERASER:'<svg viewBox="0 0 24 24"><path d="M20 8L12 20L4 20L3 17L11 5Z" fill="none" stroke="white" stroke-width="1.8" stroke-linejoin="round"/><line x1="4" y1="20" x2="20" y2="20" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>',
    Tool.ZOOM_IN:'<svg viewBox="0 0 24 24"><circle cx="10" cy="10" r="7" fill="none" stroke="white" stroke-width="1.8"/><line x1="15" y1="15" x2="21" y2="21" stroke="white" stroke-width="2.2" stroke-linecap="round"/><line x1="7" y1="10" x2="13" y2="10" stroke="white" stroke-width="1.8" stroke-linecap="round"/><line x1="10" y1="7" x2="10" y2="13" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>',
    Tool.ZOOM_OUT:'<svg viewBox="0 0 24 24"><circle cx="10" cy="10" r="7" fill="none" stroke="white" stroke-width="1.8"/><line x1="15" y1="15" x2="21" y2="21" stroke="white" stroke-width="2.2" stroke-linecap="round"/><line x1="7" y1="10" x2="13" y2="10" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>',
}

def _svg_pm(svg,size=22):
    try:
        from PyQt6.QtSvg import QSvgRenderer
        s=svg.replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" ')
        r=QSvgRenderer(QByteArray(s.encode()))
        pm=QPixmap(size,size); pm.fill(Qt.GlobalColor.transparent)
        p=QPainter(pm); r.render(p); p.end(); return pm
    except Exception: return QPixmap()

class ToolButton(QAbstractButton):
    def __init__(self,tool,label,tip,parent=None):
        super().__init__(parent); self.tool=tool; self._label=label; self._tip=tip
        self.setToolTip(tip)
        self.setToolTipDuration(4000)
        self.setAttribute(Qt.WidgetAttribute.WA_AlwaysShowToolTips, True)
        self.setCheckable(True); self.setFixedSize(36,36)
        self._pm=_svg_pm(SVGS[tool]) if tool in SVGS else QPixmap()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self.isChecked():
            p.fillRect(self.rect(),QColor(60,100,175))
            p.setPen(QColor(120,170,255)); p.drawRect(self.rect().adjusted(0,0,-1,-1))
        elif self.underMouse():
            p.fillRect(self.rect(),QColor(70,70,90))
            # Show tool name at bottom when hovered
            p.setPen(QColor(180,200,255)); p.setFont(QFont("Arial",7))
            nr=self.rect().adjusted(0,self.height()-14,0,0)
            p.drawText(nr,Qt.AlignmentFlag.AlignCenter,self._tip)
        else:
            p.fillRect(self.rect(),QColor(48,48,58))
        if self._pm and not self._pm.isNull():
            # Shift icon up slightly when hovered to make room for label
            iy_off = -5 if self.underMouse() else 0
            ix=(self.width()-self._pm.width())//2; iy=(self.height()-self._pm.height())//2+iy_off
            p.drawPixmap(ix,iy,self._pm)
        else:
            p.setPen(QColor(200,200,200)); p.setFont(QFont("Courier",8,QFont.Weight.Bold))
            p.drawText(self.rect().adjusted(0,-8,0,-8),Qt.AlignmentFlag.AlignCenter,self._label)


# ─────────────────────────────────────────────────────────────
# Color swatch
# ─────────────────────────────────────────────────────────────
class ColorSwatch(QWidget):
    colorChanged=pyqtSignal(QColor,bool)
    def __init__(self,parent=None):
        super().__init__(parent); self.fg=QColor(0,0,0); self.bg=QColor(255,255,255)
        self.setFixedSize(60,60)
    def paintEvent(self,e):
        p=QPainter(self)
        p.fillRect(20,20,35,35,self.bg); p.setPen(Qt.GlobalColor.black); p.drawRect(20,20,35,35)
        p.fillRect(5,5,35,35,self.fg); p.drawRect(5,5,35,35)
        p.setPen(QColor(200,200,200)); p.setFont(QFont("Arial",9))
        p.drawText(QRect(42,2,16,16),Qt.AlignmentFlag.AlignCenter,"⇄")
        p.setFont(QFont("Arial",7)); p.drawText(QRect(2,44,16,14),Qt.AlignmentFlag.AlignCenter,"D")
    def mousePressEvent(self,e):
        pos=e.position().toPoint()
        if QRect(42,2,16,16).contains(pos):
            self.fg,self.bg=self.bg,self.fg; self.update(); return
        if QRect(2,44,16,14).contains(pos):
            self.fg=QColor(0,0,0); self.bg=QColor(255,255,255); self.update(); return
        parent=self.window()
        if QRect(5,5,35,35).contains(pos):
            c=QColorDialog.getColor(self.fg, parent, "Foreground",
              QColorDialog.ColorDialogOption.ShowAlphaChannel)
            if c.isValid():
                self.fg=c; self.colorChanged.emit(c,True); self.update()
        elif QRect(20,20,35,35).contains(pos):
            c=QColorDialog.getColor(self.bg, parent, "Background",
              QColorDialog.ColorDialogOption.ShowAlphaChannel)
            if c.isValid():
                self.bg=c; self.colorChanged.emit(c,False); self.update()

# ─────────────────────────────────────────────────────────────
# Toolbox
# ─────────────────────────────────────────────────────────────
class Toolbox(QWidget):
    toolSelected=pyqtSignal(Tool)
    TOOLS=[
        (Tool.MARQUEE_RECT,    "[M]","Rectangular Marquee"),
        (Tool.MARQUEE_ELLIPSE, "(M)","Elliptical Marquee"),
        (Tool.LASSO,           "Las","Lasso"),
        (Tool.MAGIC_WAND,      "Wnd","Magic Wand"),
        (Tool.MOVE,            "Mov","Move"),
        (Tool.CROP,            "Crp","Crop"),
        (Tool.EYEDROPPER,      "Eye","Eyedropper"),
        (Tool.PAINT_BUCKET,    "Bkt","Paint Bucket"),
        (Tool.BRUSH,           "Brs","Brush"),
        (Tool.AIRBRUSH,        "Air","Airbrush"),
        (Tool.PENCIL,          "Pen","Pencil"),
        (Tool.ERASER,          "Era","Eraser"),
        (Tool.ZOOM_IN,         "Z+", "Zoom In"),
        (Tool.ZOOM_OUT,        "Z-", "Zoom Out"),
    ]
    def __init__(self,parent=None):
        super().__init__(parent); self.setFixedWidth(80); self.setStyleSheet("background:#303038;")
        gl=QGridLayout(self); gl.setSpacing(2); gl.setContentsMargins(4,4,4,4)
        self._grp=QButtonGroup(self); self._grp.setExclusive(True)
        for i,(t,lb,tp) in enumerate(self.TOOLS):
            btn=ToolButton(t,lb,tp); self._grp.addButton(btn); gl.addWidget(btn,i//2,i%2)
            btn.clicked.connect(lambda _,tt=t:self.toolSelected.emit(tt))
        self.swatch=ColorSwatch()
        gl.addWidget(self.swatch,len(self.TOOLS)//2+1,0,1,2,Qt.AlignmentFlag.AlignCenter)
        sl=QLabel("Size:"); sl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sl.setStyleSheet("color:#bbb;background:transparent;")
        self.sc=QComboBox()
        for s in BRUSH_SIZES: self.sc.addItem(f"{s}px",s)
        self.sc.setCurrentIndex(2)
        gl.addWidget(sl,len(self.TOOLS)//2+2,0,1,2)
        gl.addWidget(self.sc,len(self.TOOLS)//2+3,0,1,2)
        self._grp.buttons()[0].setChecked(True)

# ─────────────────────────────────────────────────────────────
# Ruler
# ─────────────────────────────────────────────────────────────
class Ruler(QWidget):
    def __init__(self,ori,parent=None):
        super().__init__(parent); self.ori=ori
        self.zoom=1.0; self.offset=QPoint(0,0); self.unit="px"; self.dpi=72
        if ori==Qt.Orientation.Horizontal: self.setFixedHeight(20)
        else: self.setFixedWidth(20)
    def set_zoom_offset(self,z,o): self.zoom=z; self.offset=o; self.update()
    def set_unit(self,u): self.unit=u; self.update()
    def _tu(self,px):
        if self.unit=="in": return px/self.dpi
        if self.unit=="cm": return px/self.dpi*2.54
        return px
    def _lb(self,v): return str(int(v)) if self.unit=="px" else f"{v:.2f}"
    def paintEvent(self,e):
        p=QPainter(self); p.fillRect(self.rect(),QColor(42,42,50))
        p.setPen(QColor(170,170,170)); p.setFont(QFont("Arial",7))
        if self.ori==Qt.Orientation.Horizontal:
            w=self.width(); step=max(10,int(50/self.zoom))
            off=int(self.offset.x()/self.zoom); start=((-off)//step)*step; x=start
            while True:
                sx=int((x+off)*self.zoom)
                if sx>w: break
                if sx>=0: p.drawLine(sx,12,sx,20); p.drawText(sx+2,11,self._lb(self._tu(x)))
                x+=step
        else:
            h=self.height(); step=max(10,int(50/self.zoom))
            off=int(self.offset.y()/self.zoom); start=((-off)//step)*step; y=start
            while True:
                sy=int((y+off)*self.zoom)
                if sy>h: break
                if sy>=0:
                    p.drawLine(12,sy,20,sy); p.save(); p.translate(10,sy-2); p.rotate(-90)
                    p.drawText(0,0,self._lb(self._tu(y))); p.restore()
                y+=step

# ─────────────────────────────────────────────────────────────
# Layers panel
# ─────────────────────────────────────────────────────────────
class LayerRow(QWidget):
    clicked       = pyqtSignal(int, object)   # (index, modifiers)
    dbl_clicked   = pyqtSignal(int)
    vis_toggle    = pyqtSignal(int)
    opacity_changed = pyqtSignal(int, float)
    ctx_menu_req  = pyqtSignal(int, object)

    def __init__(self, index, layer, active, linked=False, parent=None):
        super().__init__(parent)
        self.index  = index
        self.active = active
        self.linked = linked
        self.setFixedHeight(60)
        self.setAutoFillBackground(False)

        lo = QVBoxLayout(self)
        lo.setContentsMargins(4, 2, 4, 2)
        lo.setSpacing(1)

        # ── top row: eye + thumb + name ──────────────────────────
        top = QHBoxLayout(); top.setSpacing(4); top.setContentsMargins(0,0,0,0)

        eye = QPushButton("👁" if layer.visible else " ")
        eye.setFixedSize(22, 22); eye.setFlat(True)
        eye.setStyleSheet("color:#ccc;font-size:12px;background:transparent;border:none;")
        eye.clicked.connect(lambda: self.vis_toggle.emit(self.index))
        top.addWidget(eye)

        # Thumbnail
        tl = QLabel(); tl.setFixedSize(36, 36)
        tl.setStyleSheet("border:1px solid #444;")
        # Make label transparent to mouse events so clicks reach the row
        tl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        # Use cached thumbnail if available
        if layer._thumb_cache is None:
            pm = QPixmap(36, 36); pm.fill(QColor(60,60,60))
            pp = QPainter(pm)
            for rr in range(6):
                for cc in range(6):
                    clr = QColor(155,155,155) if (rr+cc)%2==0 else QColor(210,210,210)
                    pp.fillRect(cc*6, rr*6, 6, 6, clr)
            try:
                th = layer.image.copy()
                th.thumbnail((36,36), PIL.Image.NEAREST)  # NEAREST = fast, good enough at 36px
                pp.drawImage(0, 0, pil_to_qimage(th))
            except Exception: pass
            pp.end(); layer._thumb_cache = pm
        tl.setPixmap(layer._thumb_cache)
        top.addWidget(tl)

        # Name + opacity pct
        info = QVBoxLayout(); info.setSpacing(0); info.setContentsMargins(0,0,0,0)
        nl = QLabel(layer.name)
        nl.setStyleSheet("color:#e0e0e0;font-size:11px;background:transparent;")
        nl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        nl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._opct_lbl = QLabel(f"{int(layer.opacity*100)}%")
        self._opct_lbl.setStyleSheet("color:#888;font-size:9px;background:transparent;")
        self._opct_lbl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        info.addWidget(nl); info.addWidget(self._opct_lbl)
        top.addLayout(info, 1)
        lo.addLayout(top)

        # ── opacity slider ────────────────────────────────────────
        orow = QHBoxLayout(); orow.setSpacing(3); orow.setContentsMargins(2,0,2,0)
        olbl = QLabel("Opacity:"); olbl.setStyleSheet("color:#777;font-size:9px;background:transparent;")
        olbl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._opslider = PrecisionSlider(Qt.Orientation.Horizontal, default=100)
        self._opslider.setRange(0, 100)
        self._opslider.setValue(int(layer.opacity * 100))
        self._opslider.setFixedHeight(12)
        self._opslider.setStyleSheet(
            "QSlider::groove:horizontal{height:3px;background:#333;border-radius:1px;}"
            "QSlider::handle:horizontal{width:8px;height:8px;margin:-3px 0;"
            "background:#7090d0;border-radius:4px;}"
            "QSlider::sub-page:horizontal{background:#5070b0;border-radius:1px;}")
        self._opslider.valueChanged.connect(self._on_opacity)
        orow.addWidget(olbl); orow.addWidget(self._opslider, 1)
        lo.addLayout(orow)

    def _on_opacity(self, v):
        self._opct_lbl.setText(f"{v}%")
        self.opacity_changed.emit(self.index, v / 100.0)

    def paintEvent(self, e):
        # Paint row background BEFORE the default paintEvent draws children.
        # We don't call super() first because that would let the widget's own
        # background show through. Instead we fill the row, then super() draws
        # children (which have transparent backgrounds) over it.
        p = QPainter(self)
        if self.active and self.linked:
            # Both active AND linked — teal tint + thick borders both sides
            p.fillRect(self.rect(), QColor(30, 90, 110))
            p.fillRect(0, 0, 5, self.height(), QColor(80, 200, 255))
            p.fillRect(self.width()-5, 0, 5, self.height(), QColor(220, 180, 60))
        elif self.active:
            # Active only — solid blue tint + bright left border
            p.fillRect(self.rect(), QColor(40, 65, 105))
            p.fillRect(0, 0, 5, self.height(), QColor(80, 140, 255))
        elif self.linked:
            # Linked but not active — solid purple tint + thick purple border
            p.fillRect(self.rect(), QColor(70, 45, 100))
            p.fillRect(0, 0, 5, self.height(), QColor(180, 120, 240))
            # Right-edge gold chain indicator
            p.fillRect(self.width()-5, 0, 5, self.height(), QColor(220, 180, 60))
        else:
            p.fillRect(self.rect(), QColor(38, 38, 48))
        p.end()
        super().paintEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.RightButton:
            self.ctx_menu_req.emit(self.index, e.globalPosition().toPoint())
        else:
            self.clicked.emit(self.index, e.modifiers())

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.dbl_clicked.emit(self.index)


class LayersPanel(QWidget):
    layer_selected  = pyqtSignal(int, object)   # (index, modifiers)
    layer_dblclick  = pyqtSignal(int)
    layer_vis       = pyqtSignal(int)
    layer_opacity   = pyqtSignal(int, float)
    layer_ctx       = pyqtSignal(int, object)
    add_req  = pyqtSignal(); del_req  = pyqtSignal()
    up_req   = pyqtSignal(); dn_req   = pyqtSignal()
    merge_req= pyqtSignal(); flat_req = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent); self.setFixedWidth(190); self.setStyleSheet("background:#26262e;")
        vl = QVBoxLayout(self); vl.setContentsMargins(0,0,0,0); vl.setSpacing(0)
        hdr = QLabel("  Layers"); hdr.setFixedHeight(24)
        hdr.setStyleSheet("background:#1a1a22;color:#aaa;font-size:11px;font-weight:bold;")
        vl.addWidget(hdr)
        self.lw = QWidget(); self.ll = QVBoxLayout(self.lw)
        self.ll.setContentsMargins(0,0,0,0); self.ll.setSpacing(1)
        self.ll.addStretch()
        sc = QScrollArea(); sc.setWidget(self.lw); sc.setWidgetResizable(True)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        sc.setStyleSheet("QScrollArea{border:none;background:#26262e;}"); vl.addWidget(sc, 1)

        def mkb(t, tip, w=36):
            b = QPushButton(t); b.setFixedSize(w, 24); b.setToolTip(tip)
            b.setStyleSheet("QPushButton{background:#3a3a4a;color:#ddd;border:none;"
                            "border-radius:3px;font-size:11px;}"
                            "QPushButton:hover{background:#505068;}"); return b

        r1 = QHBoxLayout(); r1.setSpacing(2); r1.setContentsMargins(4,4,4,2)
        self.ba  = mkb("＋","New Layer")
        self.bd  = mkb("✕","Delete Layer")
        self.bu  = mkb("▲","Move Up")
        self.bdn = mkb("▼","Move Down")
        for b in (self.ba, self.bd, self.bu, self.bdn): r1.addWidget(b)
        vl.addLayout(r1)

        r2 = QHBoxLayout(); r2.setSpacing(2); r2.setContentsMargins(4,2,4,4)
        self.bm = mkb("Merge↓","Merge Down", 64)
        self.bf = mkb("Flatten","Flatten All", 56)
        r2.addWidget(self.bm); r2.addWidget(self.bf); r2.addStretch()
        vl.addLayout(r2)

        self.ba.clicked.connect(self.add_req);   self.bd.clicked.connect(self.del_req)
        self.bu.clicked.connect(self.up_req);    self.bdn.clicked.connect(self.dn_req)
        self.bm.clicked.connect(self.merge_req); self.bf.clicked.connect(self.flat_req)

    def refresh(self, doc: "Document"):
        # Remove all rows (stretch stays at index 0)
        while self.ll.count() > 1:
            it = self.ll.takeAt(1)
            if it.widget(): it.widget().deleteLater()
        # Top layer of stack → first row after stretch (top of panel)
        linked = getattr(doc, 'linked', set()) or set()
        for i in range(len(doc.layers)-1, -1, -1):
            row = LayerRow(i, doc.layers[i],
                           active=(i == doc.active),
                           linked=(i in linked))
            row.clicked.connect(self.layer_selected)
            row.dbl_clicked.connect(self.layer_dblclick)
            row.vis_toggle.connect(self.layer_vis)
            row.opacity_changed.connect(self.layer_opacity)
            row.ctx_menu_req.connect(self.layer_ctx)
            self.ll.addWidget(row)


# Pre-rendered checkerboard tile (shared, built once)
_CHECKER_PM: QPixmap | None = None

def _get_checker_pm() -> QPixmap:
    global _CHECKER_PM
    if _CHECKER_PM is None:
        sz = 16
        _CHECKER_PM = QPixmap(sz, sz)
        p = QPainter(_CHECKER_PM)
        p.fillRect(0,  0,  sz//2, sz//2, QColor(195,195,195))
        p.fillRect(sz//2, sz//2, sz//2, sz//2, QColor(195,195,195))
        p.fillRect(sz//2, 0,     sz//2, sz//2, QColor(240,240,240))
        p.fillRect(0,  sz//2,    sz//2, sz//2, QColor(240,240,240))
        p.end()
    return _CHECKER_PM

# ─────────────────────────────────────────────────────────────
# Canvas
# ─────────────────────────────────────────────────────────────
class Canvas(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.doc:Document|None=None; self._comp:QImage|None=None
        self.zoom=1.0; self.pan=QPoint(0,0)
        self.sel_mask:PIL.Image.Image|None=None
        self._sel_bbox = None
        self._sel_shape = None  # ('rect',...)|('ellipse',...)|('poly',...)|None
        self._sel_edge_path:QPainterPath|None = None  # pixel-exact outline in image coords
        self._sel_start:QPoint|None=None; self._lasso:list[QPoint]=[]
        self._ant_off=0
        self._ant=QTimer(self); self._ant.timeout.connect(self._tick); self._ant.start(100)
        self._draw_last:QPoint|None=None; self._grad_start:QPoint|None=None
        self._pan_start:QPoint|None=None; self._move_start:QPoint|None=None
        self.text_overlay:QImage|None=None; self.text_pos=QPoint(20,20); self.text_size=QSize(0,0)
        self.text_orig:QImage|None=None       # un-rotated source for stable rotation
        self.text_angle:float=0.0              # accumulated rotation in degrees
        self._tdrag:QPoint|None=None; self._torg:QPoint|None=None
        # Free-transform float (paste/move)
        self.paste_img:PIL.Image.Image|None=None   # current rotated/transformed image
        self.paste_orig:PIL.Image.Image|None=None  # un-rotated source, for stable rotation
        self.paste_angle:float=0.0                  # accumulated rotation in degrees
        self.paste_rect:QRect|None=None             # position+size in image coords
        self.paste_drag=None                        # None|'move'|'nw'|'ne'|'sw'|'se'|'n'|'s'|'e'|'w'
        self.paste_drag_origin:QPoint|None=None    # mouse pos at drag start (image coords)
        self.paste_rect_origin:QRect|None=None     # rect at drag start
        self.paste_layer_idx:int|None=None          # idx of auto-created paste layer
        self.setMouseTracking(True); self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

    def set_doc(self,doc:Document):
        self.doc=doc; self.sel_mask=None; self._sel_bbox=None; self._sel_shape=None
        self._sel_edge_path=None
        self.paste_img=None; self.paste_rect=None; self.paste_drag=None
        self.paste_orig=None; self.paste_angle=0.0
        self.paste_layer_idx=None
        self.zoom=1.0; self.pan=QPoint(0,0)  # locked to top-left corner
        self._recomp(); self.setMinimumSize(doc.w+20,doc.h+20); self.resize(doc.w+20,doc.h+20)

    def _recomp(self):
        if self.doc: self._comp=pil_to_qimage(self.doc.composite()); self.update()

    def set_sel_mask(self, mask, shape=None):
        """Set selection mask. Builds pixel-exact QPainterPath when shape is None."""
        self.sel_mask = mask
        self._sel_shape = shape
        self._sel_edge_path = None
        self._sel_bbox = None
        if mask is None:
            self.update(); return
        arr = np.array(mask.convert("L")) > 128
        h2, w2 = arr.shape
        rows = np.any(arr, axis=1); cols = np.any(arr, axis=0)
        if rows.any() and cols.any():
            r0 = int(np.argmax(rows)); r1 = int(len(rows)-1-np.argmax(rows[::-1]))
            c0 = int(np.argmax(cols)); c1 = int(len(cols)-1-np.argmax(cols[::-1]))
            self._sel_bbox = (c0, r0, c1, r1)
        # For wand/invert/select-all (no stored shape): build pixel-exact edge path
        if shape is None and self._sel_bbox is not None:
            path = QPainterPath()
            # Vertical edges: boundaries between arr[:,x] and arr[:,x+1]
            pad_h = np.pad(arr, ((0,0),(1,1)), mode='constant')
            v_mask = pad_h[:,:-1] != pad_h[:,1:]      # shape h, w+1
            vy, vx = np.where(v_mask)
            for y, x in zip(vy.tolist(), vx.tolist()):
                path.moveTo(float(x), float(y))
                path.lineTo(float(x), float(y+1))
            # Horizontal edges: boundaries between arr[y,:] and arr[y+1,:]
            pad_v = np.pad(arr, ((1,1),(0,0)), mode='constant')
            h_mask = pad_v[:-1,:] != pad_v[1:,:]      # shape h+1, w
            hy, hx = np.where(h_mask)
            for y, x in zip(hy.tolist(), hx.tolist()):
                path.moveTo(float(x), float(y))
                path.lineTo(float(x+1), float(y))
            self._sel_edge_path = path
        self.update()

    def _tick(self):
        if self.sel_mask is not None or self._lasso or self.paste_img is not None:
            self._ant_off=(self._ant_off+1)%16
            self.update()

    def _build_edge_pm(self): pass  # kept for compat, no longer used

    _HANDLE_NAMES = ['nw','n','ne','w','e','sw','s','se',
                     'rot_nw','rot_ne','rot_sw','rot_se']  # rotation handles at corners

    def _paste_handles(self, sr: QRect) -> list[QRect]:
        """Return 8 resize handles + 4 rotation handles (screen coords) for the given screen rect."""
        hs = 10  # handle size in pixels — big enough to grab easily
        cx = sr.left() + sr.width()//2; cy = sr.top() + sr.height()//2
        # Resize handles
        pts = [
            (sr.left(),  sr.top()),    # nw
            (cx,         sr.top()),    # n
            (sr.right(), sr.top()),    # ne
            (sr.left(),  cy),          # w
            (sr.right(), cy),          # e
            (sr.left(),  sr.bottom()), # sw
            (cx,         sr.bottom()), # s
            (sr.right(), sr.bottom()), # se
        ]
        resize_handles = [QRect(x-hs//2, y-hs//2, hs, hs) for x,y in pts]
        
        # Rotation handles — positioned outside corners at 20px offset
        rot_offset = 20
        rot_pts = [
            (sr.left()  - rot_offset, sr.top()    - rot_offset),  # rot_nw
            (sr.right() + rot_offset, sr.top()    - rot_offset),  # rot_ne
            (sr.left()  - rot_offset, sr.bottom() + rot_offset),  # rot_sw
            (sr.right() + rot_offset, sr.bottom() + rot_offset),  # rot_se
        ]
        rot_handles = [QRect(x-hs//2, y-hs//2, hs, hs) for x,y in rot_pts]
        
        return resize_handles + rot_handles

    def _paste_hit(self, pos: QPoint):
        """Return handle name, 'move', or None for a screen-coord point."""
        if self.paste_rect is None: return None
        pr=self.paste_rect
        stl=self.i2c(QPoint(pr.left(),pr.top()))
        sbr=self.i2c(QPoint(pr.right(),pr.bottom()))
        sr=QRect(stl,sbr)
        handles=self._paste_handles(sr)
        for name,hr in zip(self._HANDLE_NAMES, handles):
            if hr.adjusted(-2,-2,2,2).contains(pos): return name
        if sr.contains(pos): return 'move'
        return None

    def _text_rot_hit(self, pos: QPoint):
        """Return 'rot_nw', 'rot_ne', 'rot_sw', 'rot_se', 'move', or None for text overlay."""
        if self.text_overlay is None or self.text_overlay.isNull(): return None
        tp = self.text_pos
        hit_w = max(self.text_size.width(), 80)
        hit_h = max(self.text_size.height(), 40)
        tl = self.i2c(tp)
        br = self.i2c(QPoint(tp.x()+hit_w, tp.y()+hit_h))
        dr = QRect(tl, br)
        
        # Check rotation handles
        hs = 10
        rot_offset = 20
        rot_handles = [
            ('rot_nw', QRect(dr.left() - rot_offset - hs//2, dr.top() - rot_offset - hs//2, hs, hs)),
            ('rot_ne', QRect(dr.right() + rot_offset - hs//2, dr.top() - rot_offset - hs//2, hs, hs)),
            ('rot_sw', QRect(dr.left() - rot_offset - hs//2, dr.bottom() + rot_offset - hs//2, hs, hs)),
            ('rot_se', QRect(dr.right() + rot_offset - hs//2, dr.bottom() + rot_offset - hs//2, hs, hs)),
        ]
        for name, hr in rot_handles:
            if hr.adjusted(-2,-2,2,2).contains(pos): return name
        
        if dr.contains(pos): return 'move'
        return None

    def c2i(self,pt): return QPoint(int((pt.x()-self.pan.x())/self.zoom),int((pt.y()-self.pan.y())/self.zoom))
    def i2c(self,pt): return QPoint(int(pt.x()*self.zoom+self.pan.x()),int(pt.y()*self.zoom+self.pan.y()))
    def clamp(self,pt):
        if not self.doc: return pt
        return QPoint(max(0,min(pt.x(),self.doc.w-1)),max(0,min(pt.y(),self.doc.h-1)))

    def paintEvent(self,e):
        p=QPainter(self); p.fillRect(self.rect(),QColor(38,38,46))
        if not self.doc or not self._comp: return
        iw=int(self.doc.w*self.zoom); ih=int(self.doc.h*self.zoom)
        cx,cy=self.pan.x(),self.pan.y()

        # Checkerboard
        checker=_get_checker_pm()
        ts=max(8,int(16*self.zoom))
        if ts!=checker.width():
            checker=checker.scaled(ts,ts,Qt.AspectRatioMode.IgnoreAspectRatio,
                                   Qt.TransformationMode.FastTransformation)
        p.save(); p.setClipRect(cx,cy,iw,ih)
        p.drawTiledPixmap(cx,cy,iw,ih,checker)
        p.restore()

        p.drawImage(QRect(cx,cy,iw,ih),self._comp)

        # Selection outline — draw actual shape, not just bounding box
        if self.sel_mask is not None:
            def _sel_pens(p):
                pen = QPen(QColor(255,255,255), 1, Qt.PenStyle.DashLine)
                pen.setDashPattern([6,4]); pen.setDashOffset(self._ant_off); p.setPen(pen)
            def _sel_pens2(p):
                pen2 = QPen(QColor(0,0,0), 1, Qt.PenStyle.DashLine)
                pen2.setDashPattern([6,4]); pen2.setDashOffset(self._ant_off+5); p.setPen(pen2)

            drawn = False
            if self._sel_shape is not None:
                stype = self._sel_shape[0]
                if stype == 'rect':
                    x0,y0,x1,y1 = self._sel_shape[1]
                    tl=self.i2c(QPoint(x0,y0)); br=self.i2c(QPoint(x1,y1))
                    r = QRect(tl,br)
                    _sel_pens(p); p.drawRect(r)
                    _sel_pens2(p); p.drawRect(r)
                    drawn = True
                elif stype == 'ellipse':
                    x0,y0,x1,y1 = self._sel_shape[1]
                    tl=self.i2c(QPoint(x0,y0)); br=self.i2c(QPoint(x1,y1))
                    r = QRect(tl,br)
                    _sel_pens(p); p.drawEllipse(r)
                    _sel_pens2(p); p.drawEllipse(r)
                    drawn = True
                elif stype == 'poly':
                    pts = [self.i2c(QPoint(x,y)) for x,y in self._sel_shape[1]]
                    if len(pts) > 1:
                        path = QPainterPath()
                        path.moveTo(QPointF(pts[0]))
                        for pt in pts[1:]: path.lineTo(QPointF(pt))
                        path.closeSubpath()
                        _sel_pens(p); p.drawPath(path)
                        _sel_pens2(p); p.drawPath(path)
                        drawn = True
            # Pixel-exact edge path for wand/invert selections
            if not drawn and self._sel_edge_path is not None:
                from PyQt6.QtGui import QTransform
                xf = QTransform()
                xf.translate(self.pan.x(), self.pan.y())
                xf.scale(self.zoom, self.zoom)
                p.save()
                p.setWorldTransform(xf, True)  # apply to painter — Qt handles it, no new path object
                _sel_pens(p); p.drawPath(self._sel_edge_path)
                _sel_pens2(p); p.drawPath(self._sel_edge_path)
                p.restore()
                drawn = True
            # Last fallback (select-all, etc.): bounding box rect
            if not drawn and self._sel_bbox is not None:
                c0,r0,c1,r1 = self._sel_bbox
                tl = self.i2c(QPoint(c0,r0)); br = self.i2c(QPoint(c1+1,r1+1))
                r = QRect(tl,br)
                _sel_pens(p); p.drawRect(r)
                _sel_pens2(p); p.drawRect(r)

        # Lasso rubber-band: draw in-progress polygon as user drags
        if self._lasso and len(self._lasso) > 1:
            pts = [self.i2c(pt) for pt in self._lasso]
            pen = QPen(QColor(255,255,255), 1, Qt.PenStyle.SolidLine)
            p.setPen(pen)
            for i in range(len(pts)-1):
                p.drawLine(pts[i], pts[i+1])
            # Close hint: dotted line back to start
            pen3 = QPen(QColor(200,200,200), 1, Qt.PenStyle.DotLine)
            p.setPen(pen3); p.drawLine(pts[-1], pts[0])

        if self.text_overlay:
            tl=self.i2c(self.text_pos); dw=int(self.text_size.width()*self.zoom); dh=int(self.text_size.height()*self.zoom)
            dr=QRect(tl.x(),tl.y(),dw,dh); p.drawImage(dr,self.text_overlay)
            pen=QPen(QColor(80,160,255),1,Qt.PenStyle.DashLine); pen.setDashPattern([4,3]); p.setPen(pen)
            p.drawRect(dr.adjusted(-1,-1,1,1))
            # Add rotation handles for text
            hs = 10
            rot_offset = 20
            rot_pts = [
                (dr.left() - rot_offset, dr.top() - rot_offset),
                (dr.right() + rot_offset, dr.top() - rot_offset),
                (dr.left() - rot_offset, dr.bottom() + rot_offset),
                (dr.right() + rot_offset, dr.bottom() + rot_offset),
            ]
            p.setBrush(QColor(255,200,100))
            p.setPen(QPen(QColor(200,120,0), 2))
            for x, y in rot_pts:
                p.drawEllipse(QRect(x-hs//2, y-hs//2, hs, hs))

        # Free-transform paste float
        if self.paste_img is not None and self.paste_rect is not None:
            pr = self.paste_rect
            stl = self.i2c(QPoint(pr.left(), pr.top()))
            sbr = self.i2c(QPoint(pr.right(), pr.bottom()))
            sr = QRect(stl, sbr)
            # Draw the floating image scaled to current rect
            qi = pil_to_qimage(self.paste_img.resize(
                (max(1,pr.width()), max(1,pr.height())), PIL.Image.BILINEAR))
            p.drawImage(sr, qi)
            # Border
            p.setPen(QPen(QColor(60,120,255), 1, Qt.PenStyle.SolidLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(sr)
            # Handles — resize (square) + rotation (circular)
            handles=self._paste_handles(sr)
            # First 8 are resize handles (square, white fill, blue border)
            for i, hr in enumerate(handles[:8]):
                p.fillRect(hr, QColor(255,255,255))
                p.setPen(QPen(QColor(0,80,200), 1)); p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRect(hr)
            # Last 4 are rotation handles (circular, green fill, darker green border)
            p.setBrush(QColor(100,255,150))
            p.setPen(QPen(QColor(0,180,60), 2))
            for hr in handles[8:]:
                p.drawEllipse(hr)
            # Hint
            p.setPen(QColor(180,220,255)); p.setFont(QFont("Arial",8))
            p.drawText(stl.x(), stl.y()-4, "Drag square handles to resize · Drag circles to rotate · Enter to commit · Esc to cancel")


# ─────────────────────────────────────────────────────────────
# Main window
# ─────────────────────────────────────────────────────────────
class PhotoOfDeath(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}"); self.resize(1300,850)
        # Set window icon — taskbar/window decoration on all platforms
        ico_path = resource_path("icon.ico")
        if os.path.exists(ico_path):
            self.setWindowIcon(QIcon(ico_path))
        self.current_tool=Tool.MARQUEE_RECT; self.wand_tol=WAND_TOL_MED
        self.wand_contiguous=True; self.wand_antialias=True
        self.brush_size=5; self.grad_type="linear"
        self._ruler_unit="px"; self._dpi=72
        # Debounce compositing
        self._recomp_timer=QTimer(self); self._recomp_timer.setSingleShot(True)
        self._recomp_timer.setInterval(16)
        self._recomp_timer.timeout.connect(self._do_recomp)
        # Sub-window state: maps QMdiSubWindow → dict with doc, canvas, scroll, history, etc.
        self._subs: dict = {}
        self._last_active_sw = None  # Track for Windows (where activeSubWindow can briefly return None)
        self._build_ui(); self._build_menus(); self._connect(); self._upd_title()

    # ── active sub-window helpers ──────────────────────────────
    @property
    def _sw(self):
        """Active sub-window state dict, or None."""
        sw = self.mdi.activeSubWindow()
        return self._subs.get(sw) if sw else None

    @property
    def doc(self):
        s = self._sw; return s['doc'] if s else None

    @property
    def canvas(self):
        s = self._sw; return s['canvas'] if s else None

    @property
    def scroll(self):
        s = self._sw; return s['scroll'] if s else None

    @property
    def _fpath(self):
        s = self._sw; return s.get('fpath') if s else None
    @_fpath.setter
    def _fpath(self, v):
        s = self._sw
        if s: s['fpath'] = v

    @property
    def _mod(self):
        s = self._sw; return s.get('mod', False) if s else False
    @_mod.setter
    def _mod(self, v):
        s = self._sw
        if s: s['mod'] = v

    @property
    def _hist(self):
        s = self._sw; return s.get('hist', []) if s else []
    @_hist.setter
    def _hist(self, v):
        s = self._sw
        if s: s['hist'] = v

    @property
    def _hidx(self):
        s = self._sw; return s.get('hidx', -1) if s else -1
    @_hidx.setter
    def _hidx(self, v):
        s = self._sw
        if s: s['hidx'] = v

    @property
    def _sub_dpi(self):
        """DPI of the active sub-window."""
        s = self._sw; return s.get('dpi', self._dpi) if s else self._dpi
    @_sub_dpi.setter
    def _sub_dpi(self, v):
        s = self._sw
        if s:
            s['dpi'] = v
            s['rh'].dpi = v; s['rv'].dpi = v

    # ── UI ────────────────────────────────────────────────────
    def _build_ui(self):
        c=QWidget(); self.setCentralWidget(c)
        root=QHBoxLayout(c); root.setSpacing(0); root.setContentsMargins(0,0,0,0)
        self.toolbox=Toolbox(); root.addWidget(self.toolbox)
        self.mdi=QMdiArea()
        self.mdi.setStyleSheet("QMdiArea{background:#262630;}")
        self.mdi.subWindowActivated.connect(self._on_sub_activated)
        root.addWidget(self.mdi, 1)
        self.lp=LayersPanel(); root.addWidget(self.lp)
        self.status=QStatusBar(); self.setStatusBar(self.status)
        self.lz=QLabel("Zoom:100%"); self.lpos=QLabel("X:0 Y:0")
        self.lsz=QLabel("W:0 H:0"); self.llyr=QLabel("Layer: —")
        unit_lbl=QLabel("Units:")
        self.bunit=QPushButton("px"); self.bunit.setFixedWidth(48)
        self.bunit.setToolTip("Click to cycle ruler units: px → in → cm")
        self.bunit.setStyleSheet(
            "QPushButton{background:#505060;color:#eee;border:1px solid #888;"
            "border-radius:3px;padding:1px 4px;font-weight:bold;}"
            "QPushButton:hover{background:#6060a0;}")
        self.bunit.clicked.connect(self._cycle_units)
        for w in (self.lz,QLabel(" | "),self.lpos,QLabel(" | "),self.lsz,
                  QLabel(" | "),self.llyr,QLabel(" | "),unit_lbl,self.bunit):
            self.status.addWidget(w)
        self._rulers_visible = True

    def _create_sub(self, doc, fpath=None):
        """Create a new MDI sub-window for a document with rulers."""
        container=QWidget()
        cgl=QGridLayout(container); cgl.setSpacing(0); cgl.setContentsMargins(0,0,0,0)
        rh=Ruler(Qt.Orientation.Horizontal); rv=Ruler(Qt.Orientation.Vertical)
        rh.dpi=self._dpi; rv.dpi=self._dpi
        corner=QWidget(); corner.setFixedSize(20,20); corner.setStyleSheet("background:#2a2a32;")
        scroll=QScrollArea(); scroll.setWidgetResizable(False)
        scroll.setStyleSheet("QScrollArea{background:#262630;border:none;}")
        canvas=Canvas(); canvas.setMinimumSize(400,300)
        scroll.setWidget(canvas)
        cgl.addWidget(corner,0,0); cgl.addWidget(rh,0,1)
        cgl.addWidget(rv,1,0); cgl.addWidget(scroll,1,1)
        # Show/hide rulers based on current toggle
        rh.setVisible(self._rulers_visible); rv.setVisible(self._rulers_visible)
        corner.setVisible(self._rulers_visible)
        sw=self.mdi.addSubWindow(container)
        name = Path(fpath).name if fpath else "Untitled"
        sw.setWindowTitle(name)
        sw.resize(min(doc.w+60,900), min(doc.h+80,700))
        state = {
            'doc': doc, 'canvas': canvas, 'scroll': scroll, 'subwin': sw,
            'rh': rh, 'rv': rv, 'corner': corner,
            'fpath': fpath, 'mod': False,
            'hist': [], 'hidx': -1,
            'dpi': self._dpi,
        }
        self._subs[sw] = state
        # Wire canvas events
        canvas.mousePressEvent   = self._press
        canvas.mouseMoveEvent    = self._move
        canvas.mouseReleaseEvent = self._release
        canvas.wheelEvent        = self._wheel
        canvas.customContextMenuRequested.connect(self._ctx)
        # Wire scroll bars to update rulers
        scroll.horizontalScrollBar().valueChanged.connect(lambda: self._sync_rulers())
        scroll.verticalScrollBar().valueChanged.connect(lambda: self._sync_rulers())
        canvas.set_doc(doc)
        sw.show()
        self.mdi.setActiveSubWindow(sw)
        self._push()
        self.lp.refresh(doc)
        self._sync_rulers(); self._upd_status(); self._upd_title()
        return sw

    def _on_sub_activated(self, sw):
        """Called when user switches between sub-windows."""
        if sw and sw in self._subs:
            # Track this as the last known active sub-window — Windows can
            # return None from activeSubWindow() during menu/dialog interactions.
            self._last_active_sw = sw
            s = self._subs[sw]
            s['rh'].dpi = s.get('dpi', self._dpi)
            s['rv'].dpi = s.get('dpi', self._dpi)
            self.lp.refresh(s['doc'])
            self._sync_rulers(); self._upd_status(); self._upd_title()
        elif not sw:
            self.lp.refresh(Document(1,1))
            self._upd_title()

    def _resolve_active_sw(self):
        """Get the active sub-window, falling back to last-known if None.
        Windows can return None from activeSubWindow() during menu interactions.
        Also filters out QMdiSubWindow objects whose C++ side has been deleted."""
        def _alive(sw):
            """True if Python ref AND C++ Qt object are both still valid."""
            if sw is None: return False
            try:
                # Touching any Qt method raises RuntimeError if the C++ object is gone.
                sw.windowTitle()
                return True
            except RuntimeError:
                return False
        # Drop any dead entries from _subs first
        for dead in [sw for sw in list(self._subs.keys()) if not _alive(sw)]:
            del self._subs[dead]
            if self._last_active_sw is dead:
                self._last_active_sw = None
        # Try the normal active-window query
        try:
            sw = self.mdi.activeSubWindow()
        except RuntimeError:
            sw = None
        if _alive(sw) and sw in self._subs:
            return sw
        # Fall back to last-known
        if _alive(self._last_active_sw) and self._last_active_sw in self._subs:
            return self._last_active_sw
        # Last resort: pick any one from the list
        try:
            sub_list = [s for s in self.mdi.subWindowList() if _alive(s) and s in self._subs]
        except RuntimeError:
            sub_list = []
        if len(sub_list) >= 1:
            return sub_list[0]
        return None

    # ── menus ─────────────────────────────────────────────────
    def _build_menus(self):
        mb=self.menuBar()
        fm=mb.addMenu("File")
        self._a(fm,"New…",self._fnew,"Ctrl+N"); self._a(fm,"Open…",self._fopen,"Ctrl+O")
        self._a(fm,"Open Project…",self._fopen_project)
        self._a(fm,"Close",self._fclose,"Ctrl+W"); fm.addSeparator()
        self._a(fm,"Save",self._fsave,"Ctrl+S"); self._a(fm,"Save As…",self._fsaveas,"Ctrl+Shift+S")
        self._a(fm,"Save Project…",self._fsave_project)
        self._a(fm,"Revert",self._frevert); fm.addSeparator()
        self._a(fm,"Info…",self._file_info,"Ctrl+Alt+I"); fm.addSeparator()
        self._a(fm,"Exit",self.close,"Ctrl+Q")
        em=mb.addMenu("Edit")
        self._a(em,"Undo",self._undo,"Ctrl+Z")
        em.addSeparator()
        self._a(em,"Cut",self._cut,"Ctrl+X"); self._a(em,"Copy",self._copy,"Ctrl+C")
        self._a(em,"Paste",self._paste,"Ctrl+V"); self._a(em,"Paste as New Layer",self._paste_layer)
        self._a(em,"Clear",self._clear,"Del"); em.addSeparator()
        self._a(em,"Select All",self._sel_all,"Ctrl+A"); self._a(em,"Deselect",self._desel,"Ctrl+D")
        self._a(em,"Invert Selection",self._inv_sel,"Ctrl+Shift+I"); em.addSeparator()
        self._a(em,"Fill FG",self._fill_fg,"Alt+Backspace"); self._a(em,"Fill BG",self._fill_bg,"Ctrl+Backspace")
        em.addSeparator(); tr=em.addMenu("Transform")
        self._a(tr,"Rotate…",self._rotate)
        self._a(tr,"Flip Horizontal",self._flip_h); self._a(tr,"Flip Vertical",self._flip_v)
        lm=mb.addMenu("Layer")
        self._a(lm,"New Layer",self._lnew,"Ctrl+Shift+N"); self._a(lm,"Delete Layer",self._ldel)
        self._a(lm,"Duplicate Layer",self._ldup); lm.addSeparator()
        self._a(lm,"Move Up",self._lup); self._a(lm,"Move Down",self._ldn); lm.addSeparator()
        self._a(lm,"Merge Down",self._lmerge); self._a(lm,"Flatten Image",self._lflat,"Ctrl+Shift+F")
        lm.addSeparator(); self._a(lm,"Place Text…",self._place_text,"Ctrl+T")
        self._a(lm,"Flatten Text",self._flatten_text)
        # View menu
        vm=mb.addMenu("View")
        self._rulers_act=self._a(vm,"Show Rulers",self._toggle_rulers,"Ctrl+R")
        self._rulers_act.setCheckable(True); self._rulers_act.setChecked(True)
        vm.addSeparator()
        self._a(vm,"Zoom In",lambda:self._zoom_center(1.25),"Ctrl++")
        self._a(vm,"Zoom Out",lambda:self._zoom_center(0.8),"Ctrl+-")
        self._a(vm,"Fit on Screen",self._zoom_fit,"Ctrl+0")
        im=mb.addMenu("Image"); adj=im.addMenu("Adjustments")
        self._a(adj,"Brightness/Contrast…",self._adj_bc); self._a(adj,"Hue/Saturation…",self._adj_hs)
        self._a(adj,"Invert",self._adj_inv,"Ctrl+I"); self._a(adj,"Grayscale",self._adj_gray)
        self._a(adj,"Threshold…",self._adj_thr)
        im.addSeparator(); self._a(im,"Image Size…",self._img_size); self._a(im,"Canvas Size…",self._canv_size)
        self._a(im,"Crop to Selection",self._crop_to_selection)
        im.addSeparator(); rc=im.addMenu("Rotate Canvas")
        self._a(rc,"90° CW",lambda:self._rot_canvas(90)); self._a(rc,"90° CCW",lambda:self._rot_canvas(-90))
        self._a(rc,"180°",lambda:self._rot_canvas(180))
        self._a(rc,"Flip Horizontal",self._flip_canvas_h); self._a(rc,"Flip Vertical",self._flip_canvas_v)
        self._a(rc,"Arbitrary…",self._rot_canvas_dlg)
        # Window menu for MDI management
        wm=mb.addMenu("Window")
        self._a(wm,"Cascade",self.mdi.cascadeSubWindows)
        self._a(wm,"Tile",self.mdi.tileSubWindows)
        wm.addSeparator()
        self._a(wm,"Minimize All",self._win_minimize_all)
        self._a(wm,"Restore All",self._win_restore_all)

    def _a(self,menu,name,slot,sc=None):
        act=QAction(name,self)
        if sc: act.setShortcut(QKeySequence(sc))
        act.triggered.connect(slot); menu.addAction(act); return act

    # ── signals ───────────────────────────────────────────────
    def _connect(self):
        self.toolbox.toolSelected.connect(self._on_tool)
        self.toolbox.sc.currentIndexChanged.connect(
            lambda _:setattr(self,'brush_size',self.toolbox.sc.currentData()))
        lp=self.lp
        lp.layer_selected.connect(self._lsel); lp.layer_dblclick.connect(self._ldblclick)
        lp.layer_vis.connect(self._lvis)
        lp.layer_opacity.connect(self._lopacity); lp.layer_ctx.connect(self._lctx)
        lp.add_req.connect(self._lnew); lp.del_req.connect(self._ldel)
        lp.up_req.connect(self._lup); lp.dn_req.connect(self._ldn)
        lp.merge_req.connect(self._lmerge); lp.flat_req.connect(self._lflat)

    @property
    def fg(self): return self.toolbox.swatch.fg
    @property
    def bg(self): return self.toolbox.swatch.bg
    def _rgba(self,c:QColor): return (c.red(),c.green(),c.blue(),c.alpha())

    def _on_tool(self,t:Tool):
        # Crop is an action, not a tool - execute crop and don't change tool
        if t == Tool.CROP:
            self._crop_to_selection()
            return
        self.current_tool=t
        cur={Tool.MOVE:Qt.CursorShape.SizeAllCursor,
             Tool.ZOOM_IN:Qt.CursorShape.PointingHandCursor,
             Tool.ZOOM_OUT:Qt.CursorShape.PointingHandCursor}
        self.canvas.setCursor(cur.get(t,Qt.CursorShape.CrossCursor))

    # ── rulers / status ───────────────────────────────────────
    def _sync_rulers(self):
        s = self._sw
        if not s: return
        sc=s['scroll']; rh=s['rh']; rv=s['rv']; c=s['canvas']
        hv=sc.horizontalScrollBar().value(); vv=sc.verticalScrollBar().value()
        rh.set_zoom_offset(c.zoom, QPoint(-hv,0))
        rv.set_zoom_offset(c.zoom, QPoint(0,-vv))
    def _cycle_units(self):
        u=["px","in","cm"]; self._ruler_unit=u[(u.index(self._ruler_unit)+1)%3]
        self.bunit.setText(self._ruler_unit)
        for s in self._subs.values():
            s['rh'].set_unit(self._ruler_unit); s['rv'].set_unit(self._ruler_unit)

    def _toggle_rulers(self):
        self._rulers_visible = not self._rulers_visible
        self._rulers_act.setChecked(self._rulers_visible)
        for s in self._subs.values():
            s['rh'].setVisible(self._rulers_visible)
            s['rv'].setVisible(self._rulers_visible)
            s['corner'].setVisible(self._rulers_visible)
    def _upd_status(self,pos=None):
        c=self.canvas; d=self.doc
        z=c.zoom if c else 1.0
        self.lz.setText(f"Zoom:{int(z*100)}%")
        if pos and d and c:
            ip=c.clamp(c.c2i(pos)); self.lpos.setText(f"X:{ip.x()} Y:{ip.y()}")
        if d:
            cs=getattr(d,'color_space','RGB')
            self.lsz.setText(f"{d.w}×{d.h} {cs}")
            al=d.active_layer; self.llyr.setText(f"Layer:{al.name}" if al else "Layer:—")
        else:
            self.lsz.setText("W:— H:—"); self.llyr.setText("Layer:—")
    def _upd_title(self):
        n=Path(self._fpath).name if self._fpath else "Untitled"
        mod_str=' *' if self._mod else ''
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION} — {n}{mod_str}")
        # Also update the sub-window title
        sw=self.mdi.activeSubWindow()
        if sw: sw.setWindowTitle(f"{n}{mod_str}")

    # ── history ───────────────────────────────────────────────
    def _push(self):
        """Snapshot full editable state for undo/redo. Captures:
        - layer images (via Document.snapshot)
        - active layer index
        - selection mask + shape
        - linked-layer set
        - floating text overlay (QImage) + position + size
        - floating paste image (PIL) + rect + auto-created layer index"""
        if not self.doc: return
        self._hist = self._hist[:self._hidx + 1]
        # Floating text snapshot
        text_state = None
        if self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            torig = self.canvas.text_orig
            text_state = (
                self.canvas.text_overlay.copy(),
                QPoint(self.canvas.text_pos),
                QSize(self.canvas.text_size),
                torig.copy() if (torig is not None and not torig.isNull()) else None,
                self.canvas.text_angle,
            )
        # Floating paste snapshot
        paste_state = None
        if self.canvas.paste_img is not None and self.canvas.paste_rect is not None:
            paste_state = (
                self.canvas.paste_img.copy(),
                QRect(self.canvas.paste_rect),
                self.canvas.paste_layer_idx,
                self.canvas.paste_orig.copy() if self.canvas.paste_orig else None,
                self.canvas.paste_angle,
            )
        entry = {
            'layers':   self.doc.snapshot(),
            'active':   self.doc.active,
            'doc_w':    self.doc.w,
            'doc_h':    self.doc.h,
            'sel_mask': self.canvas.sel_mask,
            'sel_shape': self.canvas._sel_shape,
            'linked':   set(self.doc.linked),
            'text':     text_state,
            'paste':    paste_state,
        }
        self._hist.append(entry)
        if len(self._hist) > MAX_HISTORY: self._hist.pop(0)
        self._hidx = len(self._hist) - 1
        self._mod = True; self._upd_title()

    def _restore_state(self, entry):
        """Apply a history entry to the current document and canvas."""
        self.doc.restore(entry['layers'])
        self.doc.active = entry['active']
        # Restore document dimensions if saved (for crop undo support)
        if 'doc_w' in entry and 'doc_h' in entry:
            self.doc.w = entry['doc_w']
            self.doc.h = entry['doc_h']
        self.doc.linked = set(entry.get('linked', set()))
        self.canvas.set_sel_mask(entry.get('sel_mask'), entry.get('sel_shape'))
        # Restore floating text overlay
        text = entry.get('text')
        if text is not None:
            # Backward-compat: 3-tuple (ov, pos, sz) or 5-tuple with orig+angle
            if len(text) == 5:
                ov, pos, sz, orig, angle = text
            else:
                ov, pos, sz = text; orig = None; angle = 0.0
            self.canvas.text_overlay = ov.copy()
            self.canvas.text_pos = QPoint(pos)
            self.canvas.text_size = QSize(sz)
            self.canvas.text_orig = orig.copy() if orig is not None else ov.copy()
            self.canvas.text_angle = angle
        else:
            self.canvas.text_overlay = None
            self.canvas.text_orig = None
            self.canvas.text_angle = 0.0
        # Restore floating paste
        paste = entry.get('paste')
        if paste is not None:
            # Backward-compat: 3-tuple (img, rect, lidx) or 5-tuple with orig+angle
            if len(paste) == 5:
                img, rect, lidx, orig, angle = paste
            else:
                img, rect, lidx = paste; orig = None; angle = 0.0
            self.canvas.paste_img = img.copy()
            self.canvas.paste_rect = QRect(rect)
            self.canvas.paste_layer_idx = lidx
            self.canvas.paste_orig = orig.copy() if orig is not None else img.copy()
            self.canvas.paste_angle = angle
        else:
            self.canvas.paste_img = None
            self.canvas.paste_rect = None
            self.canvas.paste_layer_idx = None
            self.canvas.paste_drag = None
            self.canvas.paste_orig = None
            self.canvas.paste_angle = 0.0
        self._refresh()

    def _undo(self):
        if self._hidx <= 0: return
        self._hidx -= 1
        self._restore_state(self._hist[self._hidx])

    def _redo(self):
        # Redo functionality removed
        return
    def _do_recomp(self):
        """Debounced: just recomposite canvas. Called by timer or opacity slider."""
        if self.doc: self.canvas._recomp()

    def _refresh(self):
        """Full refresh: stop debounce timer, recomposite, update layers panel and geometry."""
        self._recomp_timer.stop()
        c=self.canvas; d=self.doc
        if not c or not d: return
        c._recomp(); self.lp.refresh(d)
        w,h=d.w,d.h; z=c.zoom
        new_w=int(w*z)+40; new_h=int(h*z)+40
        c.setMinimumSize(new_w,new_h); c.resize(new_w,new_h)
        self._upd_status(); self._upd_title()

    # ── layer ops ─────────────────────────────────────────────
    def _lsel(self, i, modifiers=None):
        """Click a layer row.
        - Plain click: clears any linking, makes that layer the only active one
        - Ctrl-click: toggles that layer in the linked set; active layer is
          preserved. The active layer is implicitly part of any link group."""
        if not self.doc: return
        ctrl = False
        if modifiers is not None:
            try:
                ctrl = bool(modifiers & Qt.KeyboardModifier.ControlModifier)
            except Exception:
                ctrl = False
        if ctrl:
            linked = self.doc.linked
            if not linked:
                linked.add(self.doc.active)   # seed with current active
            if i == self.doc.active:
                linked.add(i)
            elif i in linked:
                linked.discard(i)             # toggle off
            else:
                linked.add(i)                 # toggle on, active stays put
            if len(linked) <= 1:
                self.doc.linked = set()
        else:
            self.doc.linked = set()
            self.doc.active = i
        self.lp.refresh(self.doc); self._upd_status()

    def _adj_targets(self):
        """Return layer indices that adjustments should apply to.
        Used only for non-floating cases (floating overlays are handled
        separately upstream)."""
        if not self.doc: return []
        linked = self.doc.linked
        if linked and len(linked) >= 2:
            return sorted(i for i in linked if 0 <= i < len(self.doc.layers))
        if 0 <= self.doc.active < len(self.doc.layers):
            return [self.doc.active]
        return []
    def _ldblclick(self, i):
        """Double-click a layer:
        - 'Pasted' layer with content → lift it back into floating mode so
          the user can move/resize/rotate it again with handles
        - Other layers (Background, etc.) → open text dialog to place text"""
        if not self.doc or i>=len(self.doc.layers): return
        # Switch to this layer
        self.doc.active=i
        self.lp.refresh(self.doc)
        layer = self.doc.layers[i]
        # If this is a paste layer with content, lift it back into floating mode
        if layer.name.startswith("Pasted") or layer.name.startswith("Pasted copy"):
            # If something is already floating, commit it first to avoid losing it
            if self.canvas.paste_img is not None:
                self._commit_paste()
            # Find the bounding box of non-transparent content in this layer
            try:
                arr = np.array(layer.image)
                alpha = arr[:,:,3]
                rows = np.any(alpha > 0, axis=1)
                cols = np.any(alpha > 0, axis=0)
                if not rows.any() or not cols.any():
                    # Layer is empty — nothing to lift
                    return
                r0 = int(np.argmax(rows))
                r1 = int(len(rows) - 1 - np.argmax(rows[::-1]))
                c0 = int(np.argmax(cols))
                c1 = int(len(cols) - 1 - np.argmax(cols[::-1]))
                # Extract the content as the floating image
                content = layer.image.crop((c0, r0, c1+1, r1+1))
                self._push()
                # Clear the source layer (it'll be re-baked when user commits)
                layer.image = PIL.Image.new("RGBA", (self.doc.w, self.doc.h), (0,0,0,0))
                layer._invalidate_thumb()
                # Set up the float on this same layer
                self.canvas.paste_img = content
                self.canvas.paste_orig = content.copy()
                self.canvas.paste_angle = 0.0
                self.canvas.paste_rect = QRect(c0, r0, c1-c0+1, r1-r0+1)
                self.canvas.paste_drag = None
                self.canvas.paste_layer_idx = i
                self._refresh()
            except Exception as ex:
                print(f"[Photo of Death] double-click lift failed: {ex}", flush=True)
            return
        # Otherwise: open text dialog (original behavior)
        self._place_text()
    def _lvis(self,i):
        self._push(); self.doc.layers[i].visible=not self.doc.layers[i].visible; self._refresh()
    def _lopacity(self, i, val):
        """Live opacity change — no history push (sliders fire constantly)."""
        if not self.doc or i>=len(self.doc.layers): return
        self.doc.layers[i].opacity=val
        self._recomp_timer.start()   # debounced recomp only
        self._mod=True; self._upd_title()
    def _lctx(self, i, gpos):
        """Right-click context menu on a layer row."""
        menu=QMenu(self)
        menu.addAction("Rename…").triggered.connect(lambda: self._lrename(i))
        menu.addAction("Duplicate").triggered.connect(lambda: self._ldup_idx(i))
        menu.addSeparator()
        menu.addAction("Move Up").triggered.connect(self._lup)
        menu.addAction("Move Down").triggered.connect(self._ldn)
        menu.addSeparator()
        menu.addAction("Merge Down").triggered.connect(self._lmerge)
        menu.addSeparator()
        menu.addAction("Delete Layer").triggered.connect(self._ldel)
        from PyQt6.QtCore import QPoint as _QP
        menu.exec(_QP(int(gpos.x()), int(gpos.y())) if not isinstance(gpos, _QP) else gpos)
    def _lrename(self, i):
        if not self.doc or i>=len(self.doc.layers): return
        n,ok=QInputDialog.getText(self,"Rename Layer","Name:",text=self.doc.layers[i].name)
        if ok and n.strip():
            self._push(); self.doc.layers[i].name=n.strip(); self._refresh()
    def _ldup_idx(self, i):
        if not self.doc: return
        if len(self.doc.layers)>=MAX_LAYERS: QMessageBox.warning(self,"Layers","Max 20 layers."); return
        self._push(); l=self.doc.layers[i].copy(); l.name+=" copy"
        self.doc.layers.append(l); self.doc.active=len(self.doc.layers)-1; self._refresh()
    def _lnew(self):
        if not self.doc: return
        if len(self.doc.layers)>=MAX_LAYERS: QMessageBox.warning(self,"Layers","Max 20 layers."); return
        n,ok=QInputDialog.getText(self,"New Layer","Name:",text=f"Layer {len(self.doc.layers)+1}")
        if not ok: return
        self._push(); l=Layer(self.doc.w,self.doc.h,n)
        self.doc.layers.append(l); self.doc.active=len(self.doc.layers)-1; self._refresh()
    def _ldel(self):
        if not self.doc or len(self.doc.layers)<=1: QMessageBox.warning(self,"Layers","Cannot delete only layer."); return
        # If deleting a layer that has a text overlay, clear the text overlay
        if self.canvas and self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            self.canvas.text_overlay = None
            self.canvas.text_orig = None
            self.canvas.text_angle = 0.0
            self.canvas.text_size = QSize(0, 0)
        self._push(); self.doc.layers.pop(self.doc.active)
        self.doc.active=min(self.doc.active,len(self.doc.layers)-1)
        self.doc.linked=set(); self._refresh()
    def _ldup(self):
        if not self.doc: return
        if len(self.doc.layers)>=MAX_LAYERS: QMessageBox.warning(self,"Layers","Max 20 layers."); return
        self._push(); l=self.doc.active_layer.copy(); l.name+=" copy"
        self.doc.layers.append(l); self.doc.active=len(self.doc.layers)-1
        self.doc.linked=set(); self._refresh()
    def _lup(self):
        if not self.doc: return
        i=self.doc.active
        if i>=len(self.doc.layers)-1: return
        self._push(); self.doc.layers[i],self.doc.layers[i+1]=self.doc.layers[i+1],self.doc.layers[i]
        self.doc.active=i+1
        self.doc.linked=set(); self._refresh()
    def _ldn(self):
        if not self.doc: return
        i=self.doc.active
        if i<=0: return
        self._push(); self.doc.layers[i],self.doc.layers[i-1]=self.doc.layers[i-1],self.doc.layers[i]
        self.doc.active=i-1
        self.doc.linked=set(); self._refresh()
    def _lmerge(self):
        if not self.doc or self.doc.active<=0: QMessageBox.warning(self,"Layers","No layer below."); return
        self._push()
        top=self.doc.layers[self.doc.active]; bot=self.doc.layers[self.doc.active-1]
        bot.image=PIL.Image.alpha_composite(bot.image,top.image)
        self.doc.layers.pop(self.doc.active); self.doc.active-=1
        self.doc.linked=set(); self._refresh()
    def _lflat(self):
        if not self.doc: return
        self._push(); flat=self.doc.composite()
        self.doc.layers=[Layer(self.doc.w,self.doc.h,"Background")]
        self.doc.layers[0].image=flat; self.doc.active=0
        self.doc.linked=set(); self._refresh()

    # ── doc helpers ───────────────────────────────────────────
    @property
    def _aimg(self):
        if not self.doc: return None
        al=self.doc.active_layer; return al.image if al else None
    def _set_aimg(self, img, fast=False):
        """Update active layer image.
        fast=True: debounced recomp (for repeated draw/erase strokes).
        fast=False: immediate full refresh (for one-shot ops).
        """
        if not self.doc: return
        al=self.doc.active_layer
        if not al: return
        al.image=img.convert("RGBA")
        al._invalidate_thumb()   # thumbnail must be rebuilt next lp.refresh
        if fast:
            self._recomp_timer.start()
        else:
            self._refresh()
    def _commit(self,img,clr_sel=False):
        self._push(); self._set_aimg(img)
        if clr_sel: self.canvas.set_sel_mask(None)
    def _open_doc(self, doc: Document, fpath=None):
        return self._create_sub(doc, fpath)

    # ── mouse events ──────────────────────────────────────────
    def _press(self,event):
        if not self.doc: return
        pos=event.position().toPoint(); ip=self.canvas.clamp(self.canvas.c2i(pos))
        btn=event.button()

        # ── Airbrush right-click for size ─────────────────────────
        if btn==Qt.MouseButton.RightButton and self.current_tool==Tool.AIRBRUSH:
            menu = QMenu(self)
            menu.setStyleSheet("background:#2a2a32;color:#ddd;")
            sm = menu.addMenu("Brush Size")
            for size in BRUSH_SIZES:
                action = sm.addAction(f"{size}px")
                action.triggered.connect(lambda checked, s=size: self._set_brush_size(s))
                if size == self.brush_size:
                    action.setCheckable(True)
                    action.setChecked(True)
            menu.exec(event.globalPosition().toPoint())
            return

        # ── Paste float intercept ─────────────────────────────
        if self.canvas.paste_img is not None:
            if btn==Qt.MouseButton.RightButton:
                self._cancel_paste(); return
            if btn==Qt.MouseButton.LeftButton:
                hit=self.canvas._paste_hit(pos)
                if hit is None:
                    self._commit_paste(); return   # click outside → commit
                self.canvas.paste_drag=hit
                self.canvas.paste_drag_origin=self.canvas.c2i(pos)
                self.canvas.paste_rect_origin=QRect(self.canvas.paste_rect)
                # For rotation, store initial angle
                if hit and hit.startswith('rot_'):
                    pr = self.canvas.paste_rect
                    center_x = pr.left() + pr.width() / 2
                    center_y = pr.top() + pr.height() / 2
                    mouse_x = self.canvas.paste_drag_origin.x()
                    mouse_y = self.canvas.paste_drag_origin.y()
                    import math
                    self.canvas.paste_start_angle = math.atan2(
                        mouse_y - center_y, mouse_x - center_x) * 180 / math.pi
                return

        if btn==Qt.MouseButton.LeftButton and self.canvas.text_overlay is not None:
            hit = self.canvas._text_rot_hit(pos)
            if hit:
                if hit.startswith('rot_'):
                    # Starting rotation
                    self.canvas._tdrag = hit
                    self.canvas._torg = pos
                    # Calculate initial angle
                    tp = self.canvas.text_pos
                    tw = self.canvas.text_size.width()
                    th = self.canvas.text_size.height()
                    center_x = tp.x() + tw / 2
                    center_y = tp.y() + th / 2
                    mouse_img = self.canvas.c2i(pos)
                    import math
                    self.canvas.text_start_angle = math.atan2(
                        mouse_img.y() - center_y, mouse_img.x() - center_x) * 180 / math.pi
                else:
                    # Move drag
                    self.canvas._tdrag = 'move'
                    self.canvas._torg = QPoint(self.canvas.text_pos)
                    self.canvas._tmouse_start = pos
                return
        if btn!=Qt.MouseButton.LeftButton: return
        t=self.current_tool
        if t==Tool.MARQUEE_RECT: self.canvas._sel_start=ip; self.canvas.set_sel_mask(None)
        elif t==Tool.MARQUEE_ELLIPSE: self.canvas._sel_start=ip; self.canvas.set_sel_mask(None)
        elif t==Tool.LASSO: self.canvas._lasso=[ip]; self.canvas.set_sel_mask(None)
        elif t==Tool.MAGIC_WAND: self._wand(ip, event.modifiers())
        elif t==Tool.MOVE:
            if self.doc.active == 0 and self.canvas.sel_mask is None:
                return  # Background locked
            self._push(); self.canvas._move_start=ip
        elif t==Tool.EYEDROPPER: self._eyedrop(ip,event.modifiers())
        elif t==Tool.PAINT_BUCKET: self._push(); self._bucket(ip)
        elif t in(Tool.BRUSH,Tool.PENCIL,Tool.AIRBRUSH): self._push(); self.canvas._draw_last=ip; self._draw(ip,ip)
        elif t==Tool.ERASER: self._push(); self.canvas._draw_last=ip; self._erase(ip,ip)
        elif t==Tool.ZOOM_IN: self._zoom_at(pos,1.25)
        elif t==Tool.ZOOM_OUT: self._zoom_at(pos,0.8)

    def _move(self,event):
        pos=event.position().toPoint()
        if self.doc:
            ip=self.canvas.clamp(self.canvas.c2i(pos)); self.lpos.setText(f"X:{ip.x()} Y:{ip.y()}")
        if not self.doc: return
        ip=self.canvas.clamp(self.canvas.c2i(pos)); btn=event.buttons()

        # ── Paste float drag ──────────────────────────────────
        if (self.canvas.paste_img is not None and
                self.canvas.paste_drag is not None and
                btn & Qt.MouseButton.LeftButton):
            cur=self.canvas.c2i(pos)  # unclamped for resize freedom
            cur=QPoint(int((pos.x()-self.canvas.pan.x())/self.canvas.zoom),
                       int((pos.y()-self.canvas.pan.y())/self.canvas.zoom))
            mode=self.canvas.paste_drag
            
            # Handle rotation
            if mode and mode.startswith('rot_'):
                import math
                # Ensure we have a stable un-rotated source
                if self.canvas.paste_orig is None:
                    self.canvas.paste_orig = self.canvas.paste_img.copy()
                    self.canvas.paste_angle = 0.0
                
                pr = self.canvas.paste_rect
                center_x = pr.left() + pr.width() / 2
                center_y = pr.top() + pr.height() / 2
                
                # Calculate angle from center to current mouse position
                current_angle = math.atan2(cur.y() - center_y, cur.x() - center_x) * 180 / math.pi
                start_angle = getattr(self.canvas, 'paste_start_angle', 0)
                angle_delta = current_angle - start_angle
                
                # Apply rotation
                old_rect = QRect(self.canvas.paste_rect)
                center = old_rect.center()
                
                # Calculate current display scale BEFORE rotation
                # (ratio of display rect to current image dimensions)
                cur_w = max(1, self.canvas.paste_img.width)
                cur_h = max(1, self.canvas.paste_img.height)
                scale_x = old_rect.width() / cur_w
                scale_y = old_rect.height() / cur_h
                
                # Update accumulated angle
                self.canvas.paste_angle = (self.canvas.paste_angle + angle_delta) % 360
                self.canvas.paste_start_angle = current_angle  # Update for next delta
                
                # Rotate from original
                rotated = self.canvas.paste_orig.rotate(
                    -self.canvas.paste_angle, expand=True, resample=_BICUBIC)
                self.canvas.paste_img = rotated
                
                # Apply the same display scale to the new rotated image
                new_w = max(8, int(rotated.width * scale_x))
                new_h = max(8, int(rotated.height * scale_y))
                new_rect = QRect(0, 0, new_w, new_h)
                new_rect.moveCenter(center)
                self.canvas.paste_rect = new_rect
                
                self.canvas.setCursor(Qt.CursorShape.CrossCursor)
                self.canvas.update()
                return
            
            # Handle resize and move
            orig=self.canvas.paste_drag_origin; ro=self.canvas.paste_rect_origin
            dx=cur.x()-orig.x(); dy=cur.y()-orig.y()
            r=QRect(ro)
            MIN=8
            if mode=='move':
                r.moveTopLeft(QPoint(ro.left()+dx, ro.top()+dy))
            elif mode=='nw': r.setTopLeft(QPoint(min(ro.right()-MIN,ro.left()+dx), min(ro.bottom()-MIN,ro.top()+dy)))
            elif mode=='ne': r.setTopRight(QPoint(max(ro.left()+MIN,ro.right()+dx), min(ro.bottom()-MIN,ro.top()+dy)))
            elif mode=='sw': r.setBottomLeft(QPoint(min(ro.right()-MIN,ro.left()+dx), max(ro.top()+MIN,ro.bottom()+dy)))
            elif mode=='se': r.setBottomRight(QPoint(max(ro.left()+MIN,ro.right()+dx), max(ro.top()+MIN,ro.bottom()+dy)))
            elif mode=='n': r.setTop(min(ro.bottom()-MIN,ro.top()+dy))
            elif mode=='s': r.setBottom(max(ro.top()+MIN,ro.bottom()+dy))
            elif mode=='w': r.setLeft(min(ro.right()-MIN,ro.left()+dx))
            elif mode=='e': r.setRight(max(ro.left()+MIN,ro.right()+dx))
            self.canvas.paste_rect=r
            # Update cursor
            cursors={'nw':Qt.CursorShape.SizeFDiagCursor,'se':Qt.CursorShape.SizeFDiagCursor,
                     'ne':Qt.CursorShape.SizeBDiagCursor,'sw':Qt.CursorShape.SizeBDiagCursor,
                     'n':Qt.CursorShape.SizeVerCursor,'s':Qt.CursorShape.SizeVerCursor,
                     'e':Qt.CursorShape.SizeHorCursor,'w':Qt.CursorShape.SizeHorCursor,
                     'move':Qt.CursorShape.SizeAllCursor}
            self.canvas.setCursor(cursors.get(mode,Qt.CursorShape.ArrowCursor))
            self.canvas.update(); return

        # Update cursor when hovering over paste float
        if self.canvas.paste_img is not None and not btn:
            hit=self.canvas._paste_hit(pos)
            cursors={'nw':Qt.CursorShape.SizeFDiagCursor,'se':Qt.CursorShape.SizeFDiagCursor,
                     'ne':Qt.CursorShape.SizeBDiagCursor,'sw':Qt.CursorShape.SizeBDiagCursor,
                     'n':Qt.CursorShape.SizeVerCursor,'s':Qt.CursorShape.SizeVerCursor,
                     'e':Qt.CursorShape.SizeHorCursor,'w':Qt.CursorShape.SizeHorCursor,
                     'move':Qt.CursorShape.SizeAllCursor,
                     'rot_nw':Qt.CursorShape.CrossCursor,'rot_ne':Qt.CursorShape.CrossCursor,
                     'rot_sw':Qt.CursorShape.CrossCursor,'rot_se':Qt.CursorShape.CrossCursor}
            self.canvas.setCursor(cursors.get(hit,Qt.CursorShape.ArrowCursor) if hit else Qt.CursorShape.ArrowCursor)
        if btn&Qt.MouseButton.LeftButton and self.canvas.text_overlay and self.canvas._tdrag:
            if isinstance(self.canvas._tdrag, str) and self.canvas._tdrag.startswith('rot_'):
                # Text rotation
                import math
                from PyQt6.QtGui import QTransform
                
                # Ensure stable source
                if self.canvas.text_orig is None or self.canvas.text_orig.isNull():
                    self.canvas.text_orig = self.canvas.text_overlay.copy()
                    self.canvas.text_angle = 0.0
                
                tp = self.canvas.text_pos
                tw = self.canvas.text_size.width()
                th = self.canvas.text_size.height()
                center_x = tp.x() + tw / 2
                center_y = tp.y() + th / 2
                old_center = QPoint(int(center_x), int(center_y))
                
                # Calculate angle from center to current mouse position
                mouse_img = self.canvas.c2i(pos)
                current_angle = math.atan2(mouse_img.y() - center_y, mouse_img.x() - center_x) * 180 / math.pi
                start_angle = getattr(self.canvas, 'text_start_angle', 0)
                angle_delta = current_angle - start_angle
                
                # Update accumulated angle
                self.canvas.text_angle = (self.canvas.text_angle + angle_delta) % 360
                self.canvas.text_start_angle = current_angle
                
                # Rotate from original
                t = QTransform().rotate(self.canvas.text_angle)
                new_ov = self.canvas.text_orig.transformed(
                    t, Qt.TransformationMode.SmoothTransformation)
                self.canvas.text_overlay = new_ov
                self.canvas.text_size = QSize(new_ov.width(), new_ov.height())
                self.canvas.text_pos = QPoint(old_center.x() - new_ov.width()//2,
                                              old_center.y() - new_ov.height()//2)
                self.canvas.setCursor(Qt.CursorShape.CrossCursor)
                self.canvas.update()
                return
            else:
                # Text move
                d=pos-self.canvas._tmouse_start; org=self.canvas._torg
                self.canvas.text_pos=QPoint(org.x()+int(d.x()/self.canvas.zoom),
                                             org.y()+int(d.y()/self.canvas.zoom))
                self.canvas.update(); return
        if not(btn&Qt.MouseButton.LeftButton): return
        t=self.current_tool
        if t==Tool.MARQUEE_RECT and self.canvas._sel_start:
            x0,y0=self.canvas._sel_start.x(),self.canvas._sel_start.y()
            x1,y1=max(x0,ip.x()),max(y0,ip.y()); x0,y0=min(x0,ip.x()),min(y0,ip.y())
            m=PIL.Image.new("L",(self.doc.w,self.doc.h),0)
            ImageDraw.Draw(m).rectangle([x0,y0,x1,y1],fill=255)
            self.canvas.set_sel_mask(m, ('rect',(x0,y0,x1,y1)))
        elif t==Tool.MARQUEE_ELLIPSE and self.canvas._sel_start:
            x0,y0=self.canvas._sel_start.x(),self.canvas._sel_start.y()
            x1,y1=max(x0,ip.x()),max(y0,ip.y()); x0,y0=min(x0,ip.x()),min(y0,ip.y())
            m=PIL.Image.new("L",(self.doc.w,self.doc.h),0)
            ImageDraw.Draw(m).ellipse([x0,y0,x1,y1],fill=255)
            self.canvas.set_sel_mask(m, ('ellipse',(x0,y0,x1,y1)))
        elif t==Tool.LASSO:
            # Only add point if moved ≥ 2px from last, to keep point count down
            if not self.canvas._lasso or (
                abs(ip.x()-self.canvas._lasso[-1].x()) >= 2 or
                abs(ip.y()-self.canvas._lasso[-1].y()) >= 2):
                self.canvas._lasso.append(ip)
            self.canvas.update()
        elif t==Tool.MOVE and self.canvas._move_start:
            dx=ip.x()-self.canvas._move_start.x(); dy=ip.y()-self.canvas._move_start.y()
            self.canvas._move_start=ip
            if dx or dy:
                if self.canvas.sel_mask is not None:
                    # Move selection outline only (not pixels) — PS7 behavior
                    sm=self.canvas.sel_mask
                    shifted_mask=PIL.Image.new("L",sm.size,0)
                    shifted_mask.paste(sm,(dx,dy))
                    shape=self.canvas._sel_shape
                    if shape and shape[0]=='rect':
                        x0,y0,x1,y1=shape[1]
                        shape=('rect',(x0+dx,y0+dy,x1+dx,y1+dy))
                    elif shape and shape[0]=='ellipse':
                        x0,y0,x1,y1=shape[1]
                        shape=('ellipse',(x0+dx,y0+dy,x1+dx,y1+dy))
                    elif shape and shape[0]=='poly':
                        pts=[(x+dx,y+dy) for x,y in shape[1]]
                        shape=('poly',pts)
                    else:
                        shape=None
                    self.canvas.set_sel_mask(shifted_mask, shape)
                elif self._aimg:
                    # No selection: move entire active layer
                    shifted=PIL.Image.new("RGBA",self._aimg.size,(0,0,0,0))
                    shifted.paste(self._aimg,(dx,dy))
                    self._set_aimg(shifted, fast=True)
        elif t in(Tool.BRUSH,Tool.PENCIL,Tool.AIRBRUSH) and self.canvas._draw_last:
            self._draw(self.canvas._draw_last,ip); self.canvas._draw_last=ip
        elif t==Tool.ERASER and self.canvas._draw_last:
            self._erase(self.canvas._draw_last,ip); self.canvas._draw_last=ip

    def _release(self,event):
        if not self.doc: return
        pos=event.position().toPoint(); ip=self.canvas.clamp(self.canvas.c2i(pos))
        # Paste float drag release
        if self.canvas.paste_drag is not None:
            self.canvas.paste_drag=None
            self.canvas.paste_drag_origin=None; self.canvas.paste_rect_origin=None
            self.canvas.setCursor(Qt.CursorShape.ArrowCursor)
            self.canvas.update(); return
        # Text drag release
        if self.canvas._tdrag:
            self.canvas._tdrag=None; self.canvas._torg=None; return
        t=self.current_tool

        # ── Lasso ─────────────────────────────────────────────
        if t==Tool.LASSO:
            pts=self.canvas._lasso
            if pts and len(pts)>2:
                m=PIL.Image.new("L",(self.doc.w,self.doc.h),0)
                ipts=[(p.x(),p.y()) for p in pts]
                ImageDraw.Draw(m).polygon(ipts,fill=255)
                self.canvas.set_sel_mask(m, ('poly', ipts))
            elif pts:
                self.canvas.set_sel_mask(None)
            self.canvas._lasso=[]; self.canvas.update()

        # ── Marquee (rect/ellipse): click = deselect ──────────
        elif t in (Tool.MARQUEE_RECT, Tool.MARQUEE_ELLIPSE):
            if self.canvas.sel_mask is not None:
                arr=np.array(self.canvas.sel_mask)
                if arr.sum()==0:
                    self.canvas.set_sel_mask(None)

        # ── Crop ──────────────────────────────────────────────
        # Reset shared drag state
        self.canvas._draw_last=None; self.canvas._sel_start=None
        self.canvas._pan_start=None; self.canvas._move_start=None

    def _wheel(self,event):
        d=event.angleDelta().y(); self._zoom_at(event.position().toPoint(),1.15 if d>0 else 1/1.15)

    def _ctx(self,pos):
        menu=QMenu(self); t=self.current_tool
        if t==Tool.MAGIC_WAND:
            menu.addAction(f"Tolerance: {self.wand_tol}  (right-click to change)").setEnabled(False)
            wm=menu.addMenu("Set Tolerance")
            for lb,v in [("Low (15)",15),("Medium (32)",32),("High (64)",64),("Very High (100)",100)]:
                wm.addAction(lb).triggered.connect(lambda _,vv=v:setattr(self,'wand_tol',vv))
            wm.addAction("Custom…").triggered.connect(self._wand_tol_custom)
            con_act=menu.addAction("Contiguous"); con_act.setCheckable(True)
            con_act.setChecked(self.wand_contiguous)
            con_act.triggered.connect(lambda c:setattr(self,'wand_contiguous',c))
            aa_act=menu.addAction("Anti-alias"); aa_act.setCheckable(True)
            aa_act.setChecked(self.wand_antialias)
            aa_act.triggered.connect(lambda c:setattr(self,'wand_antialias',c))
            menu.addSeparator()
        if t in (Tool.BRUSH, Tool.PENCIL, Tool.ERASER):
            sm=menu.addMenu("Brush Size")
            for s in BRUSH_SIZES:
                sm.addAction(f"{s}px").triggered.connect(
                    lambda _,ss=s:(setattr(self,'brush_size',ss),
                                   self.toolbox.sc.setCurrentIndex(BRUSH_SIZES.index(ss))))
            menu.addAction("Custom Size…").triggered.connect(self._brush_size_custom)
            menu.addSeparator()
        menu.addAction("Move").triggered.connect(lambda: self._on_tool(Tool.MOVE))
        menu.addSeparator()
        menu.addAction("Select All").triggered.connect(self._sel_all)
        menu.addAction("Deselect").triggered.connect(self._desel); menu.addSeparator()
        menu.addAction("Copy").triggered.connect(self._copy)
        menu.addAction("Paste").triggered.connect(self._paste)
        if t in(Tool.MARQUEE_RECT,Tool.MARQUEE_ELLIPSE,Tool.LASSO):
            menu.addSeparator(); menu.addAction("Invert Selection").triggered.connect(self._inv_sel)
        menu.exec(self.canvas.mapToGlobal(pos))

    def _wand_tol_custom(self):
        v,ok=QInputDialog.getInt(self,"Wand Tolerance","Tolerance (0-255):",self.wand_tol,0,255)
        if ok: self.wand_tol=v

    def _brush_size_custom(self):
        v,ok=QInputDialog.getInt(self,"Brush Size","Size (px):",self.brush_size,1,200)
        if ok: self.brush_size=v

    def _win_minimize_all(self):
        for sw in self.mdi.subWindowList():
            sw.showMinimized()
    def _win_restore_all(self):
        for sw in self.mdi.subWindowList():
            sw.showNormal()

    # ── zoom ──────────────────────────────────────────────────
    def _zoom_at(self,pos,factor):
        if not self.canvas: return
        old=self.canvas.zoom; new=max(0.05,min(32.0,old*factor)); self.canvas.zoom=new
        # Keep image pinned to top-left corner
        self.canvas.pan=QPoint(0,0)
        if self.doc:
            w=int(self.doc.w*new)+40; h=int(self.doc.h*new)+40
            self.canvas.setMinimumSize(w,h); self.canvas.resize(w,h)
        self.canvas.update(); self._sync_rulers(); self._upd_status()

    # ── drawing ───────────────────────────────────────────────
    def _draw(self,p0,p1):
        img=self._aimg
        if not img: return
        color=self._rgba(self.fg); r=self.brush_size//2
        sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        steps=max(1,int(math.hypot(p1.x()-p0.x(),p1.y()-p0.y())))
        tmp=PIL.Image.new("RGBA",img.size,(0,0,0,0)); dt=ImageDraw.Draw(tmp,"RGBA")
        if self.current_tool==Tool.PENCIL:
            dt.line([(p0.x(),p0.y()),(p1.x(),p1.y())],fill=color,width=max(1,self.brush_size))
        elif self.current_tool==Tool.AIRBRUSH:
            # Airbrush: softer, gradual buildup with 7% opacity
            air_opacity = min(255, int(color[3] * 0.07))
            air_color = (color[0], color[1], color[2], air_opacity)
            for i in range(steps+1):
                tt=i/steps; bx=int(p0.x()+(p1.x()-p0.x())*tt); by=int(p0.y()+(p1.y()-p0.y())*tt)
                dt.ellipse([bx-r,by-r,bx+r,by+r],fill=air_color)
        else:  # Tool.BRUSH
            for i in range(steps+1):
                tt=i/steps; bx=int(p0.x()+(p1.x()-p0.x())*tt); by=int(p0.y()+(p1.y()-p0.y())*tt)
                dt.ellipse([bx-r,by-r,bx+r,by+r],fill=color)
        if sm is not None:
            comp=PIL.Image.alpha_composite(img,tmp)
            ba=np.array(img); ca=np.array(comp); ba[sm]=ca[sm]
            img=PIL.Image.fromarray(ba,"RGBA")
        else: img=PIL.Image.alpha_composite(img,tmp)
        self._set_aimg(img, fast=True)

    def _erase(self,p0,p1):
        img=self._aimg
        if not img: return
        r=self.brush_size//2; sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        arr=np.array(img); steps=max(1,int(math.hypot(p1.x()-p0.x(),p1.y()-p0.y())))
        # Vectorized eraser: build set of affected pixels via numpy
        h2,w2=arr.shape[:2]
        for i in range(steps+1):
            tt=i/steps; bx=int(p0.x()+(p1.x()-p0.x())*tt); by=int(p0.y()+(p1.y()-p0.y())*tt)
            # Clamp bounding box
            y0=max(0,by-r); y1=min(h2,by+r+1); x0=max(0,bx-r); x1=min(w2,bx+r+1)
            if y0>=y1 or x0>=x1: continue
            yy,xx=np.mgrid[y0:y1,x0:x1]
            mask_circle=(xx-bx)**2+(yy-by)**2<=r*r
            if sm is not None:
                mask_circle=mask_circle & sm[y0:y1,x0:x1]
            arr[y0:y1,x0:x1][mask_circle]=[0,0,0,0]
        self._set_aimg(PIL.Image.fromarray(arr,"RGBA"), fast=True)

    def _eyedrop(self,ip,mods):
        img=self._aimg
        if not img: return
        arr=np.array(img); samps=[]
        for dy in range(-1,2):
            for dx in range(-1,2):
                px=max(0,min(ip.x()+dx,img.width-1)); py=max(0,min(ip.y()+dy,img.height-1))
                samps.append(arr[py,px])
        avg=np.mean(samps,axis=0).astype(int)
        c=QColor(int(avg[0]),int(avg[1]),int(avg[2]),int(avg[3]))
        if mods&Qt.KeyboardModifier.AltModifier: self.toolbox.swatch.bg=c
        else: self.toolbox.swatch.fg=c
        self.toolbox.swatch.update()

    def _bucket(self,ip):
        img=self._aimg
        if not img: return
        color=self._rgba(self.fg); sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        arr=np.array(img); target=tuple(arr[ip.y(),ip.x()])
        if target==color: return
        h2,w2=arr.shape[:2]; vis=np.zeros((h2,w2),bool); stack=[(ip.x(),ip.y())]
        while stack:
            cx,cy=stack.pop()
            if cx<0 or cx>=w2 or cy<0 or cy>=h2 or vis[cy,cx]: continue
            if sm is not None and not sm[cy,cx]: continue
            if not self._tol(tuple(arr[cy,cx]),target): continue
            vis[cy,cx]=True; arr[cy,cx]=color
            stack.extend([(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)])
        self._set_aimg(PIL.Image.fromarray(arr,"RGBA"))

    def _wand(self, ip: QPoint, mods=Qt.KeyboardModifier.NoModifier):
        """PS7-style Magic Wand: fast numpy candidate mask + deque BFS."""
        img=self._aimg
        if not img: return
        from collections import deque

        arr=np.array(img, dtype=np.int32)  # H×W×4
        h2,w2=arr.shape[:2]
        x0,y0=ip.x(),ip.y()
        if not (0<=x0<w2 and 0<=y0<h2): return

        # Sample target color (RGB only, ignore alpha)
        target=arr[y0,x0,:3]

        # 1. Pre-compute candidate mask: pixels within tolerance of target (Chebyshev/per-channel)
        diff=np.max(np.abs(arr[:,:,:3]-target), axis=2)  # H×W
        candidate=(diff<=self.wand_tol)  # boolean

        # 2. Build selection
        if self.wand_contiguous:
            # Flood fill from click point using BFS — only traverse candidate pixels
            sel=np.zeros((h2,w2), dtype=bool)
            if candidate[y0,x0]:
                visited=np.zeros((h2,w2), dtype=bool)
                q=deque(); q.append((x0,y0))
                while q:
                    cx,cy=q.popleft()
                    if cx<0 or cx>=w2 or cy<0 or cy>=h2: continue
                    if visited[cy,cx]: continue
                    visited[cy,cx]=True
                    if not candidate[cy,cx]: continue
                    sel[cy,cx]=True
                    q.append((cx+1,cy)); q.append((cx-1,cy))
                    q.append((cx,cy+1)); q.append((cx,cy-1))
        else:
            # Non-contiguous: select ALL similar pixels in image
            sel=candidate.copy()

        # 3. Anti-aliasing: feather border pixels based on how close diff is to tolerance
        if self.wand_antialias and self.wand_tol>0:
            # Find border pixels (selected but adjacent to non-selected)
            from PIL import ImageFilter as _IF
            sel_img=PIL.Image.fromarray(sel.astype(np.uint8)*255,"L")
            # Smooth the border slightly
            blurred=np.array(sel_img.filter(_IF.SMOOTH_MORE))/255.0
            # Keep interior pixels fully selected, blend border
            sel_float=np.where(sel, np.maximum(sel.astype(float), blurred), 0.0)
            result_mask=(np.clip(sel_float*255,0,255)).astype(np.uint8)
        else:
            result_mask=(sel*255).astype(np.uint8)

        new_mask=PIL.Image.fromarray(result_mask,"L")

        # 4. Combine with existing selection via modifiers (PS7 behavior)
        add  = bool(mods & Qt.KeyboardModifier.ShiftModifier)
        sub  = bool(mods & Qt.KeyboardModifier.AltModifier)
        if add and self.canvas.sel_mask is not None:
            old=np.array(self.canvas.sel_mask)
            result_mask=np.clip(old.astype(int)+result_mask.astype(int),0,255).astype(np.uint8)
            new_mask=PIL.Image.fromarray(result_mask,"L")
        elif sub and self.canvas.sel_mask is not None:
            old=np.array(self.canvas.sel_mask)
            result_mask=np.clip(old.astype(int)-result_mask.astype(int),0,255).astype(np.uint8)
            new_mask=PIL.Image.fromarray(result_mask,"L")

        self.canvas.set_sel_mask(new_mask)  # shape=None → bbox fallback outline

    def _tol(self,c1,c2): return all(abs(int(a)-int(b))<=self.wand_tol for a,b in zip(c1,c2))

    # ── selection ─────────────────────────────────────────────
    def _sel_all(self):
        if not self.doc: return
        self.canvas.set_sel_mask(PIL.Image.new("L",(self.doc.w,self.doc.h),255))
    def _desel(self): self.canvas.set_sel_mask(None)
    def _inv_sel(self):
        if not self.doc: return
        if not self.canvas.sel_mask: self.canvas.set_sel_mask(PIL.Image.new("L",(self.doc.w,self.doc.h),255))
        else:
            a=np.array(self.canvas.sel_mask); self.canvas.set_sel_mask(PIL.Image.fromarray(255-a,"L"))
        self.canvas.update()

    # ── clipboard ─────────────────────────────────────────────
    _clipboard:PIL.Image.Image|None=None

    def _copy(self):
        img=self._aimg
        if not img: return
        sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        if sm is None: PhotoOfDeath._clipboard=img.copy()
        else:
            arr=np.array(img); res=np.zeros_like(arr); res[sm]=arr[sm]
            PhotoOfDeath._clipboard=PIL.Image.fromarray(res,"RGBA")
    def _cut(self): self._copy(); self._clear()
    def _paste(self):
        if PhotoOfDeath._clipboard is None or not self.doc: return
        if len(self.doc.layers) >= MAX_LAYERS:
            QMessageBox.warning(self, "Layers", "Max 20 layers."); return
        clip=PhotoOfDeath._clipboard.copy()
        # Auto-crop to tight non-transparent content bounds
        arr=np.array(clip)
        alpha=arr[:,:,3]
        rows=np.any(alpha>0,axis=1); cols=np.any(alpha>0,axis=0)
        if rows.any() and cols.any():
            r0=int(np.argmax(rows)); r1=int(len(rows)-1-np.argmax(rows[::-1]))
            c0=int(np.argmax(cols)); c1=int(len(cols)-1-np.argmax(cols[::-1]))
            clip=clip.crop((c0,r0,c1+1,r1+1))
        cw,ch=clip.size
        cx=(self.doc.w-cw)//2; cy=(self.doc.h-ch)//2
        # Create destination layer up front — paste will live on its own layer
        # while still showing floating handles for drag/resize.
        self._push()
        l = Layer(self.doc.w, self.doc.h, "Pasted")
        self.doc.layers.append(l)
        self.doc.active = len(self.doc.layers) - 1
        self.canvas.paste_layer_idx = self.doc.active   # remember for commit/cancel
        self.canvas.paste_img=clip
        self.canvas.paste_orig=clip.copy()  # stable source for rotation
        self.canvas.paste_angle=0.0
        self.canvas.paste_rect=QRect(cx,cy,cw,ch)
        self.canvas.paste_drag=None
        self.lp.refresh(self.doc)
        # Force repaint — ensure canvas is visible and updated
        self.canvas.update()
        QApplication.processEvents()

    def _paste_layer(self):
        """Alias — same as Paste."""
        self._paste()

    def _commit_paste(self):
        """Commit the floating paste — bake into the auto-created paste layer."""
        if not self.doc or self.canvas.paste_img is None: return
        pr=self.canvas.paste_rect
        # Scale original to final size
        scaled=self.canvas.paste_img.resize(
            (max(1,pr.width()), max(1,pr.height())), PIL.Image.LANCZOS)
        idx = getattr(self.canvas, 'paste_layer_idx', None)
        if idx is not None and 0 <= idx < len(self.doc.layers):
            # Write into the pre-created paste layer
            l = self.doc.layers[idx]
            l.image.paste(scaled, (pr.left(), pr.top()), scaled)
            l._invalidate_thumb()
            self.doc.active = idx
        else:
            # Fallback (shouldn't happen): create a new layer like before
            if len(self.doc.layers) >= MAX_LAYERS:
                QMessageBox.warning(self, "Layers", "Max 20 layers."); return
            self._push()
            l = Layer(self.doc.w, self.doc.h, "Pasted")
            l.image.paste(scaled, (pr.left(), pr.top()), scaled)
            self.doc.layers.append(l); self.doc.active = len(self.doc.layers) - 1
        self.canvas.paste_img=None; self.canvas.paste_rect=None
        self.canvas.paste_layer_idx=None
        self.canvas.paste_orig=None; self.canvas.paste_angle=0.0
        self._refresh()

    def _cancel_paste(self):
        # If paste created a layer, remove it so canceling truly undoes the paste
        idx = getattr(self.canvas, 'paste_layer_idx', None)
        if self.doc and idx is not None and 0 <= idx < len(self.doc.layers):
            del self.doc.layers[idx]
            if self.doc.active >= len(self.doc.layers):
                self.doc.active = max(0, len(self.doc.layers) - 1)
            self.lp.refresh(self.doc)
        self.canvas.paste_img=None; self.canvas.paste_rect=None
        self.canvas.paste_orig=None; self.canvas.paste_angle=0.0
        self.canvas.paste_drag=None; self.canvas.paste_layer_idx=None
        self.canvas.update()
    def _clear(self):
        img=self._aimg
        if not img: return
        self._push(); sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        arr=np.array(img)
        if sm is None: arr[:]=0
        else: arr[sm]=[0,0,0,0]
        self._set_aimg(PIL.Image.fromarray(arr,"RGBA"))
    def _fill_fg(self): self._fill(self.fg)
    def _fill_bg(self): self._fill(self.bg)
    def _fill(self,color):
        if not self.doc: return
        self._push()
        sm=mask_arr(self.canvas.sel_mask,self.doc.w,self.doc.h)
        rgba=self._rgba(color)
        if sm is not None and len(self.doc.layers)<MAX_LAYERS:
            # Fill into a new layer when there's a selection
            l=Layer(self.doc.w,self.doc.h,f"Fill")
            arr=np.array(l.image); arr[sm]=rgba
            l.image=PIL.Image.fromarray(arr,"RGBA")
            self.doc.layers.append(l); self.doc.active=len(self.doc.layers)-1
            self._refresh()
        else:
            # Fill on current layer
            img=self._aimg
            if not img: return
            arr=np.array(img); arr[:]=rgba
            self._set_aimg(PIL.Image.fromarray(arr,"RGBA"))

    # ── transform ─────────────────────────────────────────────
    def _rotate(self):
        if not self.doc: return
        # Linking takes priority — if 2+ layers linked, rotate those layers,
        # ignore any floating overlay.
        linked_priority = bool(self.doc.linked) and len(self.doc.linked) >= 2
        # If there's a floating paste, transform the float instead of the
        # (empty) layer beneath it — but only if we're not prioritizing links.
        if not linked_priority and self.canvas.paste_img is not None:
            dlg = RotateDialog(self)
            if not dlg.exec(): return
            self._push()
            angle = dlg.values()
            old_rect = QRect(self.canvas.paste_rect)
            center = old_rect.center()
            # Ensure we have a stable un-rotated source. If not (e.g. older
            # state from before this feature), seed it from the current image.
            if self.canvas.paste_orig is None:
                self.canvas.paste_orig = self.canvas.paste_img.copy()
                self.canvas.paste_angle = 0.0
            # Compute user's effective display scale relative to the CURRENT
            # bounding box (before this new rotation). This way we preserve
            # whatever scale the user had set.
            cur_w = max(1, self.canvas.paste_img.width)
            cur_h = max(1, self.canvas.paste_img.height)
            scale_x = old_rect.width() / cur_w
            scale_y = old_rect.height() / cur_h
            # Accumulate angle and rotate fresh from the stable origin —
            # this prevents the bounding box from compounding.
            self.canvas.paste_angle = (self.canvas.paste_angle + angle) % 360
            rotated = self.canvas.paste_orig.rotate(
                -self.canvas.paste_angle, expand=True, resample=_BICUBIC)
            self.canvas.paste_img = rotated
            # Apply the same display scale to the new rotated bounding box,
            # centered on the original rotation pivot.
            new_w = max(8, int(rotated.width * scale_x))
            new_h = max(8, int(rotated.height * scale_y))
            new_rect = QRect(0, 0, new_w, new_h)
            new_rect.moveCenter(center)
            self.canvas.paste_rect = new_rect
            self.canvas.update()
            return
        # If there's a floating text overlay, rotate around its visible center.
        if not linked_priority and self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            dlg = RotateDialog(self)
            if not dlg.exec(): return
            self._push()
            angle = dlg.values()
            from PyQt6.QtGui import QTransform
            old_pos = self.canvas.text_pos
            old_sz = self.canvas.text_size
            old_center = QPoint(old_pos.x() + old_sz.width()//2,
                                old_pos.y() + old_sz.height()//2)
            # Use the stable un-rotated source so successive rotations don't
            # compound the expanded bounding box.
            if self.canvas.text_orig is None or self.canvas.text_orig.isNull():
                self.canvas.text_orig = self.canvas.text_overlay.copy()
                self.canvas.text_angle = 0.0
            self.canvas.text_angle = (self.canvas.text_angle + angle) % 360
            t = QTransform().rotate(self.canvas.text_angle)
            new_ov = self.canvas.text_orig.transformed(
                t, Qt.TransformationMode.SmoothTransformation)
            self.canvas.text_overlay = new_ov
            self.canvas.text_size = QSize(new_ov.width(), new_ov.height())
            self.canvas.text_pos = QPoint(old_center.x() - new_ov.width()//2,
                                          old_center.y() - new_ov.height()//2)
            self.canvas.update()
            return
        # Layer branch: rotate active layer or all linked layers
        dlg=RotateDialog(self)
        if not dlg.exec(): return
        angle=dlg.values()
        targets = self._adj_targets()
        if not targets: return
        self._push()
        for idx in targets:
            img = self.doc.layers[idx].image
            rotated = img.rotate(-angle, expand=True, resample=_BICUBIC)
            result = PIL.Image.new("RGBA", (self.doc.w, self.doc.h), (0,0,0,0))
            ox = (self.doc.w - rotated.width) // 2
            oy = (self.doc.h - rotated.height) // 2
            result.paste(rotated, (ox, oy), rotated)
            self.doc.layers[idx].image = result
            self.doc.layers[idx]._invalidate_thumb()
        self._refresh()

    def _flip_h(self):
        if not self.doc: return
        # Linking takes priority
        linked_priority = bool(self.doc.linked) and len(self.doc.linked) >= 2
        # Flip floating paste in place — only if not prioritizing links
        if not linked_priority and self.canvas.paste_img is not None:
            self._push()
            self.canvas.paste_img = self.canvas.paste_img.transpose(_FLIP_LR)
            # Also flip the un-rotated source so subsequent rotations rotate
            # the flipped content; reset accumulated angle since the flipped
            # source IS the new origin.
            if self.canvas.paste_orig is not None:
                self.canvas.paste_orig = self.canvas.paste_orig.transpose(_FLIP_LR)
            self.canvas.paste_angle = 0.0
            self.canvas.update(); return
        # Flip floating text in place (QImage.mirrored)
        if not linked_priority and self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            self._push()
            self.canvas.text_overlay = self.canvas.text_overlay.mirrored(True, False)
            if self.canvas.text_orig is not None and not self.canvas.text_orig.isNull():
                self.canvas.text_orig = self.canvas.text_orig.mirrored(True, False)
            self.canvas.text_angle = 0.0
            self.canvas.update(); return
        # Layer branch: flip active layer or all linked layers
        targets = self._adj_targets()
        if not targets: return
        self._push()
        for idx in targets:
            self.doc.layers[idx].image = self.doc.layers[idx].image.transpose(_FLIP_LR)
            self.doc.layers[idx]._invalidate_thumb()
        self._refresh()

    def _flip_v(self):
        if not self.doc: return
        # Linking takes priority
        linked_priority = bool(self.doc.linked) and len(self.doc.linked) >= 2
        # Flip floating paste in place — only if not prioritizing links
        if not linked_priority and self.canvas.paste_img is not None:
            self._push()
            self.canvas.paste_img = self.canvas.paste_img.transpose(_FLIP_TB)
            if self.canvas.paste_orig is not None:
                self.canvas.paste_orig = self.canvas.paste_orig.transpose(_FLIP_TB)
            self.canvas.paste_angle = 0.0
            self.canvas.update(); return
        # Flip floating text in place (QImage.mirrored)
        if not linked_priority and self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            self._push()
            self.canvas.text_overlay = self.canvas.text_overlay.mirrored(False, True)
            if self.canvas.text_orig is not None and not self.canvas.text_orig.isNull():
                self.canvas.text_orig = self.canvas.text_orig.mirrored(False, True)
            self.canvas.text_angle = 0.0
            self.canvas.update(); return
        # Layer branch: flip active layer or all linked layers
        targets = self._adj_targets()
        if not targets: return
        self._push()
        for idx in targets:
            self.doc.layers[idx].image = self.doc.layers[idx].image.transpose(_FLIP_TB)
            self.doc.layers[idx]._invalidate_thumb()
        self._refresh()

    # ── rotate canvas ─────────────────────────────────────────
    def _rot_canvas(self,angle):
        if not self.doc: return
        self._push()
        for l in self.doc.layers:
            l.image=l.image.rotate(-angle,expand=True,resample=_BICUBIC)
            l._invalidate_thumb()
        s=self.doc.layers[0].image; self.doc.w,self.doc.h=s.width,s.height; self._refresh()
    def _flip_canvas_h(self):
        if not self.doc: return
        self._push()
        for l in self.doc.layers: l.image=l.image.transpose(_FLIP_LR); l._invalidate_thumb()
        self._refresh()
    def _flip_canvas_v(self):
        if not self.doc: return
        self._push()
        for l in self.doc.layers: l.image=l.image.transpose(_FLIP_TB); l._invalidate_thumb()
        self._refresh()
    def _rot_canvas_dlg(self):
        dlg=RotateDialog(self)
        if dlg.exec(): self._rot_canvas(dlg.values())

    # ── adjustments ───────────────────────────────────────────
    def _blend_with_selection(self, processed, original):
        """If a selection is active, return an image where selected pixels come
        from `processed` and unselected pixels come from `original`. If no
        selection, returns `processed` unchanged."""
        if not self.doc: return processed
        sm = mask_arr(self.canvas.sel_mask, self.doc.w, self.doc.h)
        if sm is None:
            return processed
        p = np.array(processed.convert("RGBA"))
        o = np.array(original.convert("RGBA"))
        # Pad/crop arrays to match if sizes differ (shouldn't normally happen)
        if p.shape != o.shape or sm.shape != p.shape[:2]:
            return processed
        out = np.where(sm[..., None], p, o)
        return PIL.Image.fromarray(out, "RGBA")

    def _floating_image(self):
        """Return the currently-floating image as PIL RGBA, or None.
        Caller checks paste_img first since it has priority."""
        if self.canvas.paste_img is not None:
            return self.canvas.paste_img.convert("RGBA")
        if self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            return qimage_to_pil(self.canvas.text_overlay)
        return None

    def _set_floating_image(self, pil_img):
        """Write a processed PIL image back to whichever floating overlay
        is active. Caller guarantees one IS active."""
        if self.canvas.paste_img is not None:
            new = pil_img.convert("RGBA")
            self.canvas.paste_img = new
            # Adjustments redefine the un-rotated source — reset rotation state
            self.canvas.paste_orig = new.copy()
            self.canvas.paste_angle = 0.0
        elif self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            self.canvas.text_overlay = pil_to_qimage(pil_img)
        self.canvas.update()

    def _adj_bc(self):
        if not self.doc: return
        # Linking takes priority — if 2+ layers linked, adjust those layers,
        # ignore any floating overlay.
        linked_priority = bool(self.doc.linked) and len(self.doc.linked) >= 2
        # Floating overlay branch — only when no linking
        if not linked_priority:
            float_img = self._floating_image()
            if float_img is not None:
                dlg = BrightnessContrastDialog(float_img, self)
                self._adj_float_orig = float_img
                dlg.preview_changed.connect(self._preview_adj_float)
                if dlg.exec():
                    self._push()
                    dlg._src = float_img
                    self._set_floating_image(dlg._apply())
                else:
                    self._set_floating_image(float_img)
                self._adj_float_orig = None
                return
        # Layer branch (single active layer OR linked group)
        img = self._aimg
        if not img: return
        targets = self._adj_targets()
        self._adj_orig = img.copy()
        self._adj_orig_per_layer = {idx: self.doc.layers[idx].image.copy()
                                     for idx in targets}
        dlg = BrightnessContrastDialog(img, self)
        self._adj_dlg = dlg  # Store for preview method
        dlg.preview_changed.connect(self._preview_adj)
        if dlg.exec():
            # Apply to all target layers FIRST, then push to history
            for idx in targets:
                src = self._adj_orig_per_layer[idx]
                dlg._src = src
                processed = dlg._apply()
                blended = self._blend_with_selection(processed, src)
                self.doc.layers[idx].image = blended.convert("RGBA")
                self.doc.layers[idx]._invalidate_thumb()
            self._push()
            self._refresh()
        else:
            for idx, orig in self._adj_orig_per_layer.items():
                self.doc.layers[idx].image = orig
                self.doc.layers[idx]._invalidate_thumb()
            self.canvas._recomp()
        self._adj_orig = None
        self._adj_orig_per_layer = None
        self._adj_dlg = None

    def _preview_adj(self, preview_img):
        """Live-preview update. For linked layers (2+), applies to all of them.
        For single layer, applies to active layer only."""
        if not self.doc: return
        
        # Check if we have linked layers and access to the dialog + originals
        adj_orig_per_layer = getattr(self, '_adj_orig_per_layer', None)
        adj_dlg = getattr(self, '_adj_dlg', None)
        
        if adj_orig_per_layer and adj_dlg and len(adj_orig_per_layer) >= 2:
            # Preview on all linked layers
            for idx, orig in adj_orig_per_layer.items():
                if idx < len(self.doc.layers):
                    adj_dlg._src = orig
                    processed = adj_dlg._apply()
                    blended = self._blend_with_selection(processed, orig)
                    self.doc.layers[idx].image = blended.convert("RGBA")
            self.canvas._recomp()
        else:
            # Single layer preview (original behavior)
            al = self.doc.active_layer
            if not al: return
            orig = getattr(self, '_adj_orig', None)
            if orig is not None:
                blended = self._blend_with_selection(preview_img, orig)
                al.image = blended.convert("RGBA")
            else:
                al.image = preview_img.convert("RGBA")
            self.canvas._recomp()

    def _preview_adj_float(self, preview_img):
        """Live-preview update for floating overlays."""
        self._set_floating_image(preview_img)

    def _adj_hs(self):
        if not self.doc: return
        # Linking takes priority over floating overlay
        linked_priority = bool(self.doc.linked) and len(self.doc.linked) >= 2
        if not linked_priority:
            float_img = self._floating_image()
            if float_img is not None:
                dlg = HueSaturationDialog(float_img, self)
                self._adj_float_orig = float_img
                dlg.preview_changed.connect(self._preview_adj_float)
                if dlg.exec():
                    self._push()
                    dlg._src = float_img
                    self._set_floating_image(dlg._apply())
                else:
                    self._set_floating_image(float_img)
                self._adj_float_orig = None
                return
        img = self._aimg
        if not img: return
        targets = self._adj_targets()
        self._adj_orig = img.copy()
        self._adj_orig_per_layer = {idx: self.doc.layers[idx].image.copy()
                                     for idx in targets}
        dlg = HueSaturationDialog(img, self)
        self._adj_dlg = dlg  # Store for preview method
        dlg.preview_changed.connect(self._preview_adj)
        if dlg.exec():
            # Apply to all target layers FIRST, then push to history
            for idx in targets:
                src = self._adj_orig_per_layer[idx]
                dlg._src = src
                processed = dlg._apply()
                blended = self._blend_with_selection(processed, src)
                self.doc.layers[idx].image = blended.convert("RGBA")
                self.doc.layers[idx]._invalidate_thumb()
            self._push()
            self._refresh()
        else:
            for idx, orig in self._adj_orig_per_layer.items():
                self.doc.layers[idx].image = orig
                self.doc.layers[idx]._invalidate_thumb()
            self.canvas._recomp()
        self._adj_orig = None
        self._adj_orig_per_layer = None
        self._adj_dlg = None

    def _apply_to_targets(self, fn):
        """Apply `fn(pil) -> pil` to the right target(s):
        - 2+ linked layers → all linked layers (linking wins over floating)
        - Floating overlay present → the overlay
        - Otherwise → active layer
        Selection mask is honored on layer ops."""
        if not self.doc: return
        # Linking takes priority. If multiple layers are linked, the user
        # explicitly asked for those layers — even if a paste/text float exists.
        linked = self.doc.linked
        if linked and len(linked) >= 2:
            targets = sorted(i for i in linked if 0 <= i < len(self.doc.layers))
            if not targets: return
            self._push()
            import hashlib
            for idx in targets:
                src = self.doc.layers[idx].image
                pre = hashlib.md5(src.tobytes()).hexdigest()[:8]
                alpha_sum = int(np.array(src.split()[3]).sum())
                processed = fn(src)
                blended = self._blend_with_selection(processed, src)
                new_img = blended.convert("RGBA")
                post = hashlib.md5(new_img.tobytes()).hexdigest()[:8]
                print(f"[Photo of Death] layer {idx} '{self.doc.layers[idx].name}' "
                      f"visible={self.doc.layers[idx].visible} alpha_sum={alpha_sum} "
                      f"hash {pre}->{post}", flush=True)
                self.doc.layers[idx].image = new_img
                self.doc.layers[idx]._invalidate_thumb()
            self._refresh()
            return
        # No linking → floating overlay takes priority over the active layer
        float_img = self._floating_image()
        if float_img is not None:
            self._push()
            self._set_floating_image(fn(float_img))
            return
        # No linking, no float → just the active layer
        if 0 <= self.doc.active < len(self.doc.layers):
            self._push()
            src = self.doc.layers[self.doc.active].image
            processed = fn(src)
            blended = self._blend_with_selection(processed, src)
            self.doc.layers[self.doc.active].image = blended.convert("RGBA")
            self.doc.layers[self.doc.active]._invalidate_thumb()
            self._refresh()

    def _adj_inv(self):
        if not self.doc: return
        def fn(img):
            alpha = img.split()[3]
            inv = ImageChops.invert(img.convert("RGB")).convert("RGBA")
            inv.putalpha(alpha)
            return inv
        self._apply_to_targets(fn)
    def _adj_gray(self):
        if not self.doc: return
        def fn(img):
            alpha = img.split()[3]
            gray = img.convert("L").convert("RGBA")
            gray.putalpha(alpha)
            return gray
        self._apply_to_targets(fn)
    def _adj_thr(self):
        if not self.doc: return
        v, ok = QInputDialog.getInt(self, "Threshold", "Threshold (0-255):", 128, 0, 255)
        if not ok: return
        def fn(img):
            arr = np.array(img); gray = np.mean(arr[:,:,:3], axis=2)
            bw = (gray >= v).astype(np.uint8) * 255
            out = np.zeros_like(arr)
            out[:,:,0] = bw; out[:,:,1] = bw; out[:,:,2] = bw; out[:,:,3] = arr[:,:,3]
            return PIL.Image.fromarray(out, "RGBA")
        self._apply_to_targets(fn)

    # ── image / canvas size ───────────────────────────────────
    def _img_size(self):
        # Use resolver — Windows can silently drop activation between dialog
        # close and the property setters firing, which would silently no-op
        # color_space and DPI updates.
        active_sw = self._resolve_active_sw()
        if not active_sw: return
        s = self._subs[active_sw]
        doc = s.get('doc')
        if not doc: return
        cur_cs = getattr(doc, 'color_space', 'RGB')
        cur_dpi = s.get('dpi', self._dpi)
        dlg = ImageSizeDialog(doc.w, doc.h, cur_dpi, cur_cs, parent=self)
        if dlg.exec():
            nw, nh, new_dpi, new_cs = dlg.values()
            self._push()
            # Write directly to state — bypasses property setters that depend
            # on active sub-window lookup (Windows quirk).
            doc.color_space = new_cs
            s['dpi'] = new_dpi
            try:
                s['rh'].dpi = new_dpi; s['rv'].dpi = new_dpi
            except RuntimeError: pass
            print(f"[Photo of Death] _img_size: dpi={new_dpi}, color_space={new_cs}", flush=True)
            for l in doc.layers:
                l.image = l.image.resize((nw, nh), PIL.Image.LANCZOS)
                l._invalidate_thumb()
            doc.w, doc.h = nw, nh
            self._refresh()
    def _canv_size(self):
        active_sw = self._resolve_active_sw()
        if not active_sw: return
        s = self._subs[active_sw]
        doc = s.get('doc')
        if not doc: return
        dlg = CanvasSizeDialog(doc.w, doc.h, self)
        if dlg.exec():
            nw, nh = dlg.values()
            self._push()
            ow, oh = doc.w, doc.h
            # Center the existing content in the new canvas
            ox = (nw - ow) // 2; oy = (nh - oh) // 2
            for l in doc.layers:
                n = PIL.Image.new("RGBA", (nw, nh), (0, 0, 0, 0))
                n.paste(l.image, (ox, oy)); l.image = n; l._invalidate_thumb()
            doc.w, doc.h = nw, nh
            self._refresh()

    def _crop_to_selection(self):
        """Crop the canvas to the current selection bounds."""
        if not self.doc or not self.canvas or not self.canvas.sel_mask:
            QMessageBox.information(self, "Crop", "No selection to crop to. Use selection tools first.")
            return
        # Find bounding box of selection
        sm = np.array(self.canvas.sel_mask)
        rows = np.any(sm, axis=1)
        cols = np.any(sm, axis=0)
        if not np.any(rows) or not np.any(cols):
            QMessageBox.information(self, "Crop", "Selection is empty.")
            return
        y0, y1 = np.where(rows)[0][[0, -1]]
        x0, x1 = np.where(cols)[0][[0, -1]]
        # Add 1 to make inclusive
        x1 += 1; y1 += 1
        # Crop all layers to this region
        self._push()
        new_w, new_h = x1 - x0, y1 - y0
        for layer in self.doc.layers:
            cropped = layer.image.crop((x0, y0, x1, y1))
            layer.image = cropped
            layer._invalidate_thumb()
        self.doc.w, self.doc.h = new_w, new_h
        # Clear selection after crop
        self.canvas.set_sel_mask(None)
        self._refresh()

    def _set_brush_size(self, size):
        """Set brush size and update combo box."""
        self.brush_size = size
        if size in BRUSH_SIZES:
            self.toolbox.sc.setCurrentIndex(BRUSH_SIZES.index(size))

    # ── text ──────────────────────────────────────────────────
    def _guard_text(self):
        if not self.canvas: return False
        if not self.canvas.text_overlay: return False
        QMessageBox.information(self,"Text","Flatten or cancel current text first (Layer menu)."); return True

    def _place_text(self):
        if not self.doc: return
        # If there's an existing text overlay, cancel it first (don't flatten)
        if self.canvas and self.canvas.text_overlay:
            self._cancel_text()
        dlg=TextDialog(self.fg,self)
        if not dlg.exec(): return
        params=dlg.values()
        if not params["text"].strip(): return
        if len(self.doc.layers)>=MAX_LAYERS: QMessageBox.warning(self,"Layers","Max 20 layers."); return
        self._push()
        tl=Layer(self.doc.w,self.doc.h,"Text")
        self.doc.layers.append(tl); self.doc.active=len(self.doc.layers)-1
        self.lp.refresh(self.doc)
        # Render text overlay
        font=params["font"]; color=params["color"]; text=params["text"]; align=params["align"]
        orientation=params.get("orientation","Horizontal")
        fm=QFontMetrics(font)
        if orientation == "Vertical":
            # Stack each character on its own line, top to bottom.
            # Width = widest char + padding. Height = sum of line heights.
            # Each character is horizontally centered in the column so narrow
            # letters (I, l, i, .) don't hug an edge while wide ones fill it.
            line_h = fm.height()
            chars = list(text)
            tw = min(max((fm.horizontalAdvance(c) for c in chars), default=0) + 8, self.doc.w)
            th = min(line_h * len(chars) + 8, self.doc.h)
            ov = QImage(tw, th, QImage.Format.Format_RGBA8888); ov.fill(QColor(0,0,0,0))
            pp = QPainter(ov); pp.setRenderHint(QPainter.RenderHint.TextAntialiasing)
            pp.setFont(font); pp.setPen(QPen(color))
            y = 0
            center_align = int(Qt.AlignmentFlag.AlignHCenter) | int(Qt.AlignmentFlag.AlignTop)
            for ch in chars:
                pp.drawText(
                    QRect(2, 2 + y, tw - 4, line_h),
                    center_align,
                    ch)
                y += line_h
            pp.end()
        else:
            tw=min(fm.horizontalAdvance(text)+8,self.doc.w); th=min(fm.height()+8,self.doc.h)
            ov=QImage(tw,th,QImage.Format.Format_RGBA8888); ov.fill(QColor(0,0,0,0))
            pp=QPainter(ov); pp.setRenderHint(QPainter.RenderHint.TextAntialiasing)
            pp.setFont(font)
            pen=QPen(color); pen.setColor(color); pp.setPen(pen)
            pp.drawText(QRect(2,2,tw-4,th-4),int(align)|int(Qt.TextFlag.TextWordWrap),text); pp.end()
        self.canvas.text_overlay=ov; self.canvas.text_size=QSize(tw,th)
        self.canvas.text_orig=ov.copy(); self.canvas.text_angle=0.0
        self.canvas.text_pos=QPoint(max(0,(self.doc.w-tw)//2),max(0,(self.doc.h-th)//2))
        self.canvas.update()
        # Text is now floating. Use Move tool to position, Layer > Flatten Text to commit.

    def _flatten_text(self):
        if not self.doc: return
        if not self.canvas or not self.canvas.text_overlay: return
        ov=self.canvas.text_overlay; w2,h2=ov.width(),ov.height()
        fmt=ov.convertToFormat(QImage.Format.Format_RGBA8888); ptr=fmt.bits(); ptr.setsize(w2*h2*4)
        text_pil=PIL.Image.frombytes("RGBA",(w2,h2),bytes(ptr))
        base=self._aimg.copy(); tx,ty=self.canvas.text_pos.x(),self.canvas.text_pos.y()
        base.paste(text_pil,(tx,ty),text_pil)
        al=self.doc.active_layer
        if al: al.image=base.convert("RGBA")
        if self.doc.active > 0:
            top=self.doc.layers[self.doc.active]
            bot=self.doc.layers[self.doc.active-1]
            merged=PIL.Image.alpha_composite(bot.image, top.image)
            bot.image=merged
            self.doc.layers.pop(self.doc.active)
            self.doc.active-=1
        self.canvas.text_overlay=None; self.canvas.text_size=QSize(0,0)
        self.canvas.text_orig=None; self.canvas.text_angle=0.0
        self._refresh()

    def _cancel_text(self):
        if not self.canvas: return
        if self.doc and self.canvas.text_overlay and len(self.doc.layers)>1:
            self.doc.layers.pop(self.doc.active)
            self.doc.active=min(self.doc.active,len(self.doc.layers)-1)
        self.canvas.text_overlay=None; self.canvas.text_size=QSize(0,0)
        self.canvas.text_orig=None; self.canvas.text_angle=0.0
        self._refresh()

    # ── file ops ──────────────────────────────────────────────
    def _fnew(self):
        dlg=NewImageDialog(dpi=self._dpi, parent=self)
        if not dlg.exec(): return
        w,h,dpi,bg,cs=dlg.values(); self._dpi=dpi
        doc=Document(w,h,cs); l=Layer(w,h,"Background",bg); doc.layers.append(l)
        self._open_doc(doc)
        self._sub_dpi=dpi  # persist into the newly created sub-window

    def _fopen(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Open","",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tiff *.tif *.ico);;All (*)")
        for path in paths:
            try:
                img=PIL.Image.open(path)
                w, h = img.size
                # Read DPI from image metadata if available
                file_dpi = self._dpi
                if hasattr(img,'info') and 'dpi' in img.info:
                    raw = img.info['dpi']
                    try:
                        val = raw[0] if isinstance(raw, (tuple, list)) else raw
                        # Use round() not int() — JPEG/PNG often store DPI as
                        # floats like 299.999 that should round to 300.
                        file_dpi = max(1, int(round(float(val))))
                    except Exception: pass
                # Detect colorspace from original mode BEFORE converting to RGBA.
                # CMYK JPEGs/TIFFs need their colorspace preserved on save.
                file_cs = "CMYK" if img.mode in ("CMYK",) else "RGB"
                print(f"[Photo of Death] _fopen: path={path}", flush=True)
                print(f"[Photo of Death] _fopen: pil_mode={img.mode}, detected dpi={file_dpi}, color_space={file_cs}", flush=True)
                img = img.convert("RGBA")
                doc=Document(w, h, color_space=file_cs)
                l=Layer.__new__(Layer); l.name="Background"; l.visible=True; l.opacity=1.0
                l._thumb_cache=None; l.image=img
                doc.layers.append(l)
                sw = self._open_doc(doc, fpath=path)
                # Write DPI directly to the state dict — bypass the property
                # setter which can silently fail on Windows when the active
                # sub-window lookup hasn't settled yet after creation.
                s = self._subs.get(sw) if sw else self._sw
                if s:
                    s['dpi'] = file_dpi
                    try:
                        s['rh'].dpi = file_dpi; s['rv'].dpi = file_dpi
                    except RuntimeError: pass
                    self._sync_rulers()
                    print(f"[Photo of Death] _fopen: wrote to state — s['dpi']={s['dpi']}, doc.color_space={s['doc'].color_space}", flush=True)
                else:
                    print(f"[Photo of Death] _fopen: WARNING — no state dict found for new sub-window!", flush=True)
            except Exception as ex: QMessageBox.critical(self,"Error",f"Cannot open:\n{ex}")

    # ── .pod project files ────────────────────────────────────
    POD_VERSION = 1

    def _fsave_project(self):
        """Save current document as a .pod (Photo of Death project) file.
        Format: ZIP containing:
          manifest.json — document metadata and layer order
          layer_NNN.png — one PNG per layer (indexed by stack position)
          text.png — floating text overlay if present
          paste.png — floating paste content if present"""
        active_sw = self._resolve_active_sw()
        if not active_sw:
            QMessageBox.warning(self, "Save Project", "No document available."); return
        s = self._subs[active_sw]
        doc = s.get('doc')
        if not doc: return
        # Use the cached canvas reference, not self.canvas — the latter goes
        # through activeSubWindow() which can return None on Windows after
        # menu interactions, causing 'NoneType has no attribute text_overlay'.
        canvas = s.get('canvas')
        if canvas is None:
            QMessageBox.warning(self, "Save Project", "Canvas unavailable."); return
        # Suggest a sensible default path
        cur = s.get('fpath', '')
        default = ""
        if cur:
            default = str(Path(cur).with_suffix('.pod'))
        path, _ = QFileDialog.getSaveFileName(self, "Save Project",
            default, "Photo of Death Project (*.pod);;All (*)")
        if not path: return
        if not path.lower().endswith('.pod'):
            path += '.pod'
        try:
            tmp = path + ".tmp"
            with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z:
                # Manifest
                manifest = {
                    'pod_version': self.POD_VERSION,
                    'app': 'Photo of Death',
                    'width': doc.w, 'height': doc.h,
                    'color_space': getattr(doc, 'color_space', 'RGB'),
                    'dpi': s.get('dpi', self._dpi),
                    'active': doc.active,
                    'linked': sorted(doc.linked),
                    'layers': [
                        {
                            'index': i,
                            'name': l.name,
                            'visible': l.visible,
                            'opacity': l.opacity,
                            'file': f"layer_{i:03d}.png",
                        }
                        for i, l in enumerate(doc.layers)
                    ],
                    'text_overlay': None,
                    'paste_overlay': None,
                }
                # Layer images
                for i, l in enumerate(doc.layers):
                    buf = io.BytesIO()
                    l.image.save(buf, format='PNG')
                    z.writestr(f"layer_{i:03d}.png", buf.getvalue())
                # Floating text overlay
                if (canvas.text_overlay is not None and
                        not canvas.text_overlay.isNull()):
                    text_pil = qimage_to_pil(canvas.text_overlay)
                    buf = io.BytesIO(); text_pil.save(buf, format='PNG')
                    z.writestr('text.png', buf.getvalue())
                    manifest['text_overlay'] = {
                        'file': 'text.png',
                        'x': canvas.text_pos.x(),
                        'y': canvas.text_pos.y(),
                        'w': canvas.text_size.width(),
                        'h': canvas.text_size.height(),
                    }
                # Floating paste
                if (canvas.paste_img is not None and
                        canvas.paste_rect is not None):
                    buf = io.BytesIO()
                    canvas.paste_img.save(buf, format='PNG')
                    z.writestr('paste.png', buf.getvalue())
                    pr = canvas.paste_rect
                    manifest['paste_overlay'] = {
                        'file': 'paste.png',
                        'x': pr.x(), 'y': pr.y(),
                        'w': pr.width(), 'h': pr.height(),
                        'layer_idx': canvas.paste_layer_idx,
                    }
                z.writestr('manifest.json', json.dumps(manifest, indent=2))
            # Atomic replace
            try:
                with open(tmp, "rb+") as f:
                    f.flush(); os.fsync(f.fileno())
            except Exception: pass
            os.replace(tmp, path)
            s['fpath'] = path
            s['mod'] = False
            self._upd_title()
            QMessageBox.information(self, "Save Project",
                f"Project saved:\n{path}")
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.critical(self, "Save Project Error",
                f"Cannot save project:\n{path}\n\n{ex}")

    def _fopen_project(self):
        """Open a .pod project file, restoring layers, overlays, and state."""
        path, _ = QFileDialog.getOpenFileName(self, "Open Project",
            "", "Photo of Death Project (*.pod);;All (*)")
        if not path: return
        try:
            with zipfile.ZipFile(path, 'r') as z:
                manifest = json.loads(z.read('manifest.json').decode('utf-8'))
                if manifest.get('pod_version', 0) > self.POD_VERSION:
                    QMessageBox.warning(self, "Open Project",
                        f"This .pod file uses a newer format (v{manifest['pod_version']}). "
                        f"Trying to open anyway, but some features may not load.")
                w = manifest['width']; h = manifest['height']
                cs = manifest.get('color_space', 'RGB')
                doc = Document(w, h, color_space=cs)
                # Load layers
                for ld in manifest['layers']:
                    img_data = z.read(ld['file'])
                    pil = PIL.Image.open(io.BytesIO(img_data)).convert("RGBA")
                    l = Layer.__new__(Layer)
                    l.name = ld['name']
                    l.visible = bool(ld.get('visible', True))
                    l.opacity = float(ld.get('opacity', 1.0))
                    l._thumb_cache = None
                    l.image = pil
                    doc.layers.append(l)
                doc.active = min(manifest.get('active', 0), len(doc.layers) - 1)
                doc.linked = set(int(i) for i in manifest.get('linked', []))
                sw = self._open_doc(doc, fpath=path)
                # Restore DPI in state
                s = self._subs.get(sw) if sw else self._sw
                if s:
                    s['dpi'] = int(manifest.get('dpi', self._dpi))
                    try:
                        s['rh'].dpi = s['dpi']; s['rv'].dpi = s['dpi']
                    except RuntimeError: pass
                    self._sync_rulers()
                # Restore floating text overlay
                tov = manifest.get('text_overlay')
                if tov:
                    text_data = z.read(tov['file'])
                    text_pil = PIL.Image.open(io.BytesIO(text_data)).convert("RGBA")
                    self.canvas.text_overlay = pil_to_qimage(text_pil)
                    self.canvas.text_orig = self.canvas.text_overlay.copy()
                    self.canvas.text_angle = 0.0
                    self.canvas.text_pos = QPoint(int(tov['x']), int(tov['y']))
                    self.canvas.text_size = QSize(int(tov['w']), int(tov['h']))
                # Restore floating paste
                pov = manifest.get('paste_overlay')
                if pov:
                    paste_data = z.read(pov['file'])
                    self.canvas.paste_img = PIL.Image.open(io.BytesIO(paste_data)).convert("RGBA")
                    self.canvas.paste_orig = self.canvas.paste_img.copy()
                    self.canvas.paste_angle = 0.0
                    self.canvas.paste_rect = QRect(
                        int(pov['x']), int(pov['y']),
                        int(pov['w']), int(pov['h']))
                    li = pov.get('layer_idx')
                    self.canvas.paste_layer_idx = int(li) if li is not None else None
                self._refresh()
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.critical(self, "Open Project Error",
                f"Cannot open project:\n{path}\n\n{ex}")

    def _fclose(self):
        sw=self.mdi.activeSubWindow()
        if not sw or sw not in self._subs: return
        s=self._subs[sw]
        if s['mod']:
            r=QMessageBox.question(self,"Unsaved","Save before closing?",
                QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel)
            if r==QMessageBox.StandardButton.Cancel: return
            if r==QMessageBox.StandardButton.Save: self._fsave()
        del self._subs[sw]
        if self._last_active_sw is sw:
            self._last_active_sw = None
        self.mdi.removeSubWindow(sw); sw.close()
        self._upd_title()

    def _ok_discard(self):
        if not self._mod: return True
        r=QMessageBox.question(self,"Unsaved","Save before continuing?",
            QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel)
        if r==QMessageBox.StandardButton.Save: self._fsave(); return True
        return r==QMessageBox.StandardButton.Discard

    def _fsave(self):
        print("[Photo of Death] _fsave called", flush=True)
        try:
            active_sw = self._resolve_active_sw()
            print(f"[Photo of Death] _fsave: resolved sub-window = {active_sw}", flush=True)
            if not active_sw:
                QMessageBox.warning(self, "Save", "No document available to save.")
                return
            s = self._subs[active_sw]
            fpath = s.get('fpath')
            print(f"[Photo of Death] _fsave: fpath = {fpath}", flush=True)
            if fpath:
                self._save_to_state(s, fpath)
            else:
                self._fsaveas()
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.critical(self, "Save Error", f"Save failed:\n{ex}")

    def _fsaveas(self):
        print("[Photo of Death] _fsaveas called", flush=True)
        try:
            active_sw = self._resolve_active_sw()
            print(f"[Photo of Death] _fsaveas: resolved sub-window = {active_sw}", flush=True)
            if not active_sw:
                QMessageBox.warning(self, "Save As", "No document available to save.")
                return
            s = self._subs[active_sw]
            doc = s.get('doc')
            if not doc:
                QMessageBox.warning(self, "Save As", "Document is empty.")
                return
            # Try to make the resolved sub-window active (best-effort)
            try: self.mdi.setActiveSubWindow(active_sw)
            except RuntimeError: pass
            # Open Image Size dialog first to allow changing DPI/dimensions (optional)
            cur_cs = getattr(doc, 'color_space', 'RGB')
            cur_dpi = s.get('dpi', self._dpi)
            dlg = ImageSizeDialog(doc.w, doc.h, cur_dpi, cur_cs, parent=self)
            if dlg.exec():
                nw, nh, new_dpi, new_cs = dlg.values()
                # If dimensions changed, resize the image
                if nw != doc.w or nh != doc.h:
                    self._push()
                    for l in doc.layers:
                        l.image = l.image.resize((nw, nh), PIL.Image.LANCZOS)
                        l._invalidate_thumb()
                    doc.w, doc.h = nw, nh
                # Update DPI and color space directly in the cached state
                s['dpi'] = new_dpi
                try:
                    s['rh'].dpi = new_dpi; s['rv'].dpi = new_dpi
                except RuntimeError: pass
                doc.color_space = new_cs
                self._refresh()
            QApplication.processEvents()
            # Always proceed to file dialog (even if Image Size was canceled)
            path, selected_filter = QFileDialog.getSaveFileName(self, "Save As", "",
                "PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp);;GIF (*.gif);;WebP (*.webp);;TIFF (*.tiff *.tif);;All (*)")
            if path:
                # Ensure file has an extension (Windows fix)
                if not Path(path).suffix:
                    if "PNG" in selected_filter: path += ".png"
                    elif "JPEG" in selected_filter: path += ".jpg"
                    elif "BMP" in selected_filter: path += ".bmp"
                    elif "GIF" in selected_filter: path += ".gif"
                    elif "WebP" in selected_filter: path += ".webp"
                    elif "TIFF" in selected_filter: path += ".tiff"
                    else: path += ".png"
                # Save directly into the cached sub-window state
                s['fpath'] = path
                self._save_to_state(s, path)
        except Exception as ex:
            import traceback; traceback.print_exc()
            QMessageBox.critical(self, "Save As Error", f"Save As failed:\n{ex}")

    def _render_for_export(self, s):
        """Composite the document AND any floating overlays (text, paste) into a single
        PIL image. The canvas's text_overlay and paste_img are visible on screen but
        not part of any layer — without this, save would write a file that doesn't
        match what the user sees. doc.composite() returns a fresh image each call,
        so we can modify `img` in place."""
        doc = s['doc']
        canvas = s.get('canvas')
        img = doc.composite()
        if canvas is None:
            return img
        # 1. Composite floating text overlay (if any)
        try:
            ov = getattr(canvas, 'text_overlay', None)
            if ov is not None and not ov.isNull():
                fmt = ov.convertToFormat(QImage.Format.Format_RGBA8888)
                w2, h2 = fmt.width(), fmt.height()
                ptr = fmt.bits(); ptr.setsize(w2 * h2 * 4)
                text_pil = PIL.Image.frombytes("RGBA", (w2, h2), bytes(ptr))
                tx = canvas.text_pos.x(); ty = canvas.text_pos.y()
                img.paste(text_pil, (tx, ty), text_pil)
                print(f"[Photo of Death] _render_for_export: composited text overlay at ({tx},{ty})", flush=True)
        except Exception as ex:
            print(f"[Photo of Death] _render_for_export: text overlay skipped: {ex}", flush=True)
        # 2. Composite floating paste image (if any)
        try:
            paste_img = getattr(canvas, 'paste_img', None)
            paste_rect = getattr(canvas, 'paste_rect', None)
            if paste_img is not None and paste_rect is not None:
                pr = paste_rect
                scaled = paste_img.resize(
                    (max(1, pr.width()), max(1, pr.height())), PIL.Image.LANCZOS)
                if scaled.mode != "RGBA":
                    scaled = scaled.convert("RGBA")
                img.paste(scaled, (pr.left(), pr.top()), scaled)
                print(f"[Photo of Death] _render_for_export: composited paste at {pr}", flush=True)
        except Exception as ex:
            print(f"[Photo of Death] _render_for_export: paste overlay skipped: {ex}", flush=True)
        return img

    def _save_to_state(self, s, path, export=False):
        """Save using a cached sub-window state dict — bypasses MDI activation lookups
        which can silently fail on Windows after modal dialogs."""
        print(f"[Photo of Death] _save_to_state called: path={path}", flush=True)
        doc = s.get('doc')
        if not doc:
            print("[Photo of Death] _save_to_state: doc is None!", flush=True)
            QMessageBox.critical(self, "Error", "No document to save.")
            return
        try:
            import os, datetime
            # Use _render_for_export so floating text/paste overlays are saved too
            img = self._render_for_export(s)
            ext = Path(path).suffix.lower()
            print(f"[Photo of Death] _save_to_state: ext={ext}, size={img.size}", flush=True)
            dpi = s.get('dpi', self._dpi)
            cs = getattr(doc, 'color_space', 'RGB')
            print(f"[Photo of Death] _save_to_state: dpi_from_state={dpi}, color_space_from_doc={cs}", flush=True)
            # CMYK can only be stored in JPEG and TIFF. If the doc is CMYK and
            # the user picks a format that doesn't support it (PNG, BMP, GIF,
            # WebP, ICO), warn them — silently dropping the colorspace causes
            # confusion, especially since the trace would show cs=CMYK going in.
            cmyk_capable = ('.jpg', '.jpeg', '.tiff', '.tif')
            if cs == 'CMYK' and ext not in cmyk_capable:
                fmt_name = {'.png':'PNG', '.bmp':'BMP', '.gif':'GIF',
                            '.webp':'WebP', '.ico':'ICO'}.get(ext, ext.upper().lstrip('.'))
                resp = QMessageBox.question(self, "CMYK Not Supported",
                    f"{fmt_name} cannot store CMYK colorspace at the file format "
                    f"level. The file will be saved as RGB instead.\n\n"
                    f"To preserve CMYK, save as JPEG or TIFF.\n\n"
                    f"Save as RGB anyway?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                if resp != QMessageBox.StandardButton.Yes:
                    print(f"[Photo of Death] _save_to_state: user canceled CMYK→RGB conversion", flush=True)
                    return
            if cs == 'CMYK' and ext in ('.tiff', '.tif', '.jpg', '.jpeg'):
                img = img.convert("CMYK")
            elif ext in ('.jpg', '.jpeg'):
                img = img.convert("RGB")
            elif ext == '.gif':
                # GIF: 8-bit indexed, 256-color adaptive palette. Preserve
                # transparency by reserving palette index 0 for fully-clear pixels.
                rgba = img.convert("RGBA")
                # Quantize the RGB part with adaptive palette (255 colors,
                # leaving slot 0 for transparency)
                quant = rgba.convert("RGB").quantize(colors=255, method=PIL.Image.Quantize.MEDIANCUT)
                # Build mask: True where original was transparent
                alpha = np.array(rgba.split()[3])
                trans_mask = alpha < 128
                # Shift all palette indices by 1 (free index 0)
                arr = np.array(quant) + 1
                arr[trans_mask] = 0
                # Rebuild image with new palette, transparent at index 0
                img = PIL.Image.fromarray(arr.astype(np.uint8), mode='P')
                pal = list(quant.getpalette()[:255*3])
                img.putpalette([0, 0, 0] + pal)  # index 0 = transparent placeholder
            save_kwargs = {}
            if ext in ('.jpg', '.jpeg'): save_kwargs['dpi'] = (dpi, dpi)
            elif ext == '.png': save_kwargs['dpi'] = (dpi, dpi)
            elif ext == '.gif': save_kwargs['transparency'] = 0
            elif ext in ('.tiff', '.tif'):
                save_kwargs['resolution'] = dpi
                save_kwargs['resolution_unit'] = 'inch'
            print(f"[Photo of Death] _save_to_state: calling img.save({path}, **{save_kwargs})", flush=True)
            # Pre-save state for comparison
            pre_exists = os.path.exists(path)
            pre_size = os.path.getsize(path) if pre_exists else 0
            pre_mtime = os.path.getmtime(path) if pre_exists else 0
            # Determine PIL format from the original extension (tmp file has .tmp ext)
            ext_to_fmt = {
                '.jpg':'JPEG', '.jpeg':'JPEG',
                '.png':'PNG', '.bmp':'BMP', '.gif':'GIF',
                '.webp':'WEBP', '.tiff':'TIFF', '.tif':'TIFF',
                '.ico':'ICO',
            }
            pil_fmt = ext_to_fmt.get(ext)
            # Atomic write: save to temp file, then replace — works around OneDrive
            # and antivirus sometimes blocking direct overwrites.
            tmp_path = path + ".tmp"
            if pil_fmt:
                img.save(tmp_path, format=pil_fmt, **save_kwargs)
            else:
                # Unknown extension — save directly without temp file
                img.save(path, **save_kwargs)
                tmp_path = None
            if tmp_path:
                # Sync to disk before rename
                try:
                    with open(tmp_path, "rb+") as f:
                        f.flush(); os.fsync(f.fileno())
                except Exception: pass
                # Replace original (os.replace is atomic on Windows)
                os.replace(tmp_path, path)
            # Verify the file actually changed on disk
            if os.path.exists(path):
                post_size = os.path.getsize(path)
                post_mtime = os.path.getmtime(path)
                mtime_str = datetime.datetime.fromtimestamp(post_mtime).strftime("%H:%M:%S")
                print(f"[Photo of Death] _save_to_state: VERIFIED on disk — size={post_size} bytes, mtime={mtime_str}", flush=True)
                if pre_exists and post_size == pre_size and post_mtime == pre_mtime:
                    msg = (f"PIL reported save succeeded, but the file on disk did not change.\n\n"
                           f"Path: {path}\n"
                           f"This is usually a OneDrive sync conflict or antivirus block.\n"
                           f"Try saving to a non-OneDrive folder (e.g. C:\\Temp).")
                    print(f"[Photo of Death] WARNING: {msg}", flush=True)
                    QMessageBox.warning(self, "Save Verification Failed", msg)
                    return
            else:
                msg = f"PIL reported save succeeded, but the file does not exist on disk:\n{path}"
                print(f"[Photo of Death] ERROR: {msg}", flush=True)
                QMessageBox.critical(self, "Save Error", msg)
                return
            print(f"[Photo of Death] _save_to_state: SAVED OK to {path}", flush=True)
            if not export:
                s['mod'] = False
                self._upd_title()
        except Exception as ex:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Save Error", f"Cannot save to:\n{path}\n\n{ex}")

    def _frevert(self):
        if not self._fpath or not self._sw: return
        r=QMessageBox.question(self,"Revert","Revert to saved?",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)
        if r==QMessageBox.StandardButton.Yes:
            try:
                path = self._fpath
                # Handle .pod project files
                if path.lower().endswith('.pod'):
                    with zipfile.ZipFile(path, 'r') as z:
                        manifest = json.loads(z.read('manifest.json').decode('utf-8'))
                        if manifest.get('pod_version', 0) > self.POD_VERSION:
                            QMessageBox.warning(self, "Revert",
                                f"This .pod file uses a newer format (v{manifest['pod_version']}). "
                                f"Trying to revert anyway, but some features may not load.")
                        w = manifest['width']; h = manifest['height']
                        cs = manifest.get('color_space', 'RGB')
                        doc = Document(w, h, color_space=cs)
                        # Load layers
                        for ld in manifest['layers']:
                            img_data = z.read(ld['file'])
                            pil = PIL.Image.open(io.BytesIO(img_data)).convert("RGBA")
                            l = Layer.__new__(Layer)
                            l.name = ld['name']
                            l.visible = bool(ld.get('visible', True))
                            l.opacity = float(ld.get('opacity', 1.0))
                            l._thumb_cache = None
                            l.image = pil
                            doc.layers.append(l)
                        doc.active = min(manifest.get('active', 0), len(doc.layers) - 1)
                        doc.linked = set(int(i) for i in manifest.get('linked', []))
                        s = self._sw
                        s['doc'] = doc
                        s['hist'] = []
                        s['hidx'] = -1
                        s['mod'] = False
                        # Restore DPI
                        s['dpi'] = int(manifest.get('dpi', self._dpi))
                        try:
                            s['rh'].dpi = s['dpi']; s['rv'].dpi = s['dpi']
                        except RuntimeError: pass
                        s['canvas'].set_doc(doc)
                        # Restore floating text overlay
                        tov = manifest.get('text_overlay')
                        if tov:
                            text_data = z.read(tov['file'])
                            text_pil = PIL.Image.open(io.BytesIO(text_data)).convert("RGBA")
                            s['canvas'].text_overlay = pil_to_qimage(text_pil)
                            s['canvas'].text_orig = s['canvas'].text_overlay.copy()
                            s['canvas'].text_angle = 0.0
                            s['canvas'].text_pos = QPoint(int(tov['x']), int(tov['y']))
                            s['canvas'].text_size = QSize(int(tov['w']), int(tov['h']))
                        else:
                            s['canvas'].text_overlay = None
                            s['canvas'].text_orig = None
                            s['canvas'].text_angle = 0.0
                        # Restore floating paste
                        pov = manifest.get('paste_overlay')
                        if pov:
                            paste_data = z.read(pov['file'])
                            s['canvas'].paste_img = PIL.Image.open(io.BytesIO(paste_data)).convert("RGBA")
                            s['canvas'].paste_orig = s['canvas'].paste_img.copy()
                            s['canvas'].paste_angle = 0.0
                            s['canvas'].paste_rect = QRect(
                                int(pov['x']), int(pov['y']),
                                int(pov['w']), int(pov['h']))
                            li = pov.get('layer_idx')
                            s['canvas'].paste_layer_idx = int(li) if li is not None else None
                        else:
                            s['canvas'].paste_img = None
                            s['canvas'].paste_rect = None
                            s['canvas'].paste_layer_idx = None
                            s['canvas'].paste_drag = None
                            s['canvas'].paste_orig = None
                            s['canvas'].paste_angle = 0.0
                        self._push()
                        self._sync_rulers()
                        self.lp.refresh(doc)
                        self._upd_title()
                        self._refresh()
                else:
                    # Handle regular image files
                    img=PIL.Image.open(path).convert("RGBA")
                    doc=Document(img.width,img.height); l=Layer(img.width,img.height,"Background")
                    l.image=img; doc.layers.append(l)
                    s=self._sw; s['doc']=doc; s['hist']=[]; s['hidx']=-1; s['mod']=False
                    s['canvas'].set_doc(doc); self._push()
                    self.lp.refresh(doc); self._upd_title()
            except Exception as ex: QMessageBox.critical(self,"Error",str(ex))

    def _fexport(self):
        path,_=QFileDialog.getSaveFileName(self,"Export","",
            "PNG (*.png);;JPEG (*.jpg *.jpeg);;BMP (*.bmp);;WebP (*.webp);;TIFF (*.tiff)")
        if path: self._save_to(path,export=True)

    def _file_info(self):
        if not self.doc:
            QMessageBox.information(self,"Info","No image open."); return
        fpath = self._fpath or "Untitled (unsaved)"
        ext   = Path(fpath).suffix.upper().lstrip('.') if self._fpath else "—"
        w,h   = self.doc.w, self.doc.h
        nlayers = len(self.doc.layers)
        # Estimate memory: each layer is w*h*4 bytes
        mem_bytes = w * h * 4 * nlayers
        if mem_bytes < 1024**2:  mem_str = f"{mem_bytes//1024} KB"
        elif mem_bytes < 1024**3: mem_str = f"{mem_bytes/1024**2:.1f} MB"
        else:                     mem_str = f"{mem_bytes/1024**3:.2f} GB"
        mode = getattr(self.doc, 'color_space', 'RGB')
        hist_entries = self._hidx + 1
        lines = [
            f"File:        {Path(fpath).name}",
            f"Location:    {Path(fpath).parent if self._fpath else '—'}",
            f"Format:      {ext}",
            "",
            f"Dimensions:  {w} × {h} px",
            f"Resolution:  {self._sub_dpi} ppi",
            f"Color Space: {mode}",
            "",
            f"Layers:      {nlayers}",
            f"Est. RAM:    {mem_str}",
            f"History:     {hist_entries} state(s)",
            f"Modified:    {'Yes' if self._mod else 'No'}",
        ]
        dlg = QDialog(self); dlg.setWindowTitle("Image Info"); dlg.setMinimumWidth(360)
        vl = QVBoxLayout(dlg)
        lbl = QLabel("\n".join(lines))
        lbl.setFont(QFont("Courier", 10))
        lbl.setStyleSheet("color:#ccc; padding:8px;")
        lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        vl.addWidget(lbl)
        ok = QPushButton("OK"); ok.clicked.connect(dlg.accept)
        br = QHBoxLayout(); br.addStretch(); br.addWidget(ok); vl.addLayout(br)
        dlg.exec()

    def _save_to(self,path,export=False):
        if not self.doc: return
        try:
            img=self.doc.composite(); ext=Path(path).suffix.lower()
            dpi=self._sub_dpi
            cs=getattr(self.doc,'color_space','RGB')
            if cs=='CMYK' and ext in('.tiff','.tif','.jpg','.jpeg'):
                img=img.convert("CMYK")
            elif ext in('.jpg','.jpeg'): img=img.convert("RGB")
            elif ext=='.gif': img=img.convert("P",dither=PIL.Image.NONE)
            # Write DPI into metadata
            save_kwargs={}
            if ext in('.jpg','.jpeg'): save_kwargs['dpi']=(dpi,dpi)
            elif ext in('.png',): save_kwargs['dpi']=(dpi,dpi)
            elif ext in('.tiff','.tif'): save_kwargs['resolution']=dpi; save_kwargs['resolution_unit']='inch'
            img.save(path, **save_kwargs)
            if not export: self._mod=False; self._upd_title()
        except Exception as ex: QMessageBox.critical(self,"Error",f"Cannot save:\n{ex}")

    def keyPressEvent(self, e):
        if self.canvas and self.canvas.paste_img is not None:
            if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._commit_paste(); return
            if e.key() == Qt.Key.Key_Escape:
                self._cancel_paste(); return
        # Handle text overlay Escape/Enter
        if self.canvas and self.canvas.text_overlay is not None and not self.canvas.text_overlay.isNull():
            if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self._flatten_text(); return
            if e.key() == Qt.Key.Key_Escape:
                self._cancel_text(); return
        # PS7 zoom shortcuts: Ctrl++ zoom in, Ctrl+- zoom out, Ctrl+0 fit
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            if e.key() in (Qt.Key.Key_Plus, Qt.Key.Key_Equal):
                self._zoom_center(1.25); return
            if e.key() == Qt.Key.Key_Minus:
                self._zoom_center(0.8); return
            if e.key() == Qt.Key.Key_0:
                self._zoom_fit(); return
        super().keyPressEvent(e)

    def _zoom_center(self, factor):
        """Zoom centered on the middle of the visible canvas area."""
        if not self.canvas: return
        sc = self.scroll
        if sc:
            vr = sc.viewport().rect()
            center = QPoint(vr.width()//2, vr.height()//2)
        else:
            center = QPoint(400, 300)
        self._zoom_at(center, factor)

    def _zoom_fit(self):
        """Fit the image to the sub-window viewport (Ctrl+0)."""
        if not self.canvas or not self.doc: return
        sc = self.scroll
        if not sc: return
        vw = sc.viewport().width(); vh = sc.viewport().height()
        fw = vw / self.doc.w; fh = vh / self.doc.h
        new_zoom = max(0.05, min(32.0, min(fw, fh)))
        self.canvas.zoom = new_zoom
        self.canvas.pan = QPoint(0, 0)
        w = int(self.doc.w * new_zoom) + 40; h = int(self.doc.h * new_zoom) + 40
        self.canvas.setMinimumSize(w, h); self.canvas.resize(w, h)
        self.canvas.update(); self._sync_rulers(); self._upd_status()

    def closeEvent(self,e):
        for sw, s in list(self._subs.items()):
            # Skip sub-windows whose C++ side has been deleted by Qt
            try:
                _ = sw.windowTitle()  # raises RuntimeError if deleted
            except RuntimeError:
                continue
            if s['mod']:
                try:
                    self.mdi.setActiveSubWindow(sw)
                except RuntimeError:
                    continue
                name = Path(s['fpath']).name if s['fpath'] else "Untitled"
                r=QMessageBox.question(self,f"Unsaved — {name}","Save before closing?",
                    QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|
                    QMessageBox.StandardButton.Cancel)
                if r==QMessageBox.StandardButton.Cancel: e.ignore(); return
                if r==QMessageBox.StandardButton.Save: self._fsave()
        e.accept()

# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────
def main():
    # Windows: set an explicit AppUserModelID BEFORE QApplication is created.
    # Without this, Windows groups the app under the Python host process and
    # uses the Python icon in the taskbar instead of the bundled icon.
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "DeathsHeadSoftware.PhotoOfDeath.1.0")
        except Exception:
            pass
    app=QApplication(sys.argv); app.setStyle("Fusion")
    # Application identity — used by Qt for various window/system integrations
    app.setApplicationName("Photo of Death")
    app.setOrganizationName("Death's Head Software")
    # Application-level window icon — used as fallback for any window without
    # its own icon, and shown in some places before the main window appears.
    ico_path = resource_path("icon.ico")
    if os.path.exists(ico_path):
        app.setWindowIcon(QIcon(ico_path))
    from PyQt6.QtGui import QPalette
    pal=QPalette()
    pal.setColor(QPalette.ColorRole.Window,          QColor(45,45,52))
    pal.setColor(QPalette.ColorRole.WindowText,      QColor(220,220,220))
    pal.setColor(QPalette.ColorRole.Base,            QColor(30,30,36))
    pal.setColor(QPalette.ColorRole.AlternateBase,   QColor(40,40,46))
    pal.setColor(QPalette.ColorRole.ToolTipBase,     QColor(50,50,58))
    pal.setColor(QPalette.ColorRole.ToolTipText,     QColor(220,220,220))
    pal.setColor(QPalette.ColorRole.Text,            QColor(220,220,220))
    pal.setColor(QPalette.ColorRole.Button,          QColor(55,55,62))
    pal.setColor(QPalette.ColorRole.ButtonText,      QColor(220,220,220))
    pal.setColor(QPalette.ColorRole.BrightText,      QColor(255,255,255))
    pal.setColor(QPalette.ColorRole.Highlight,       QColor(70,110,180))
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor(255,255,255))
    pal.setColor(QPalette.ColorRole.Mid,             QColor(35,35,40))
    pal.setColor(QPalette.ColorRole.Dark,            QColor(25,25,30))
    pal.setColor(QPalette.ColorRole.Shadow,          QColor(15,15,18))
    app.setPalette(pal)
    app.setStyleSheet(
        "QToolTip {"
        "  color: #ffffff;"
        "  background-color: #2a2a3a;"
        "  border: 1px solid #6080c0;"
        "  padding: 3px 6px;"
        "  font-size: 11px;"
        "}"
    )
    splash=create_splash()
    if splash:
        splash.show()
        for msg in ["Starting…","Loading tools…","Initialising canvas…","Ready!"]:
            splash.showMessage("\n\n\n\n\n\n\n"+msg,
                Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignCenter,QColor(255,255,255))
            app.processEvents(); time.sleep(0.4)
    win=PhotoOfDeath(); win.show()
    if splash: splash.finish(win)
    sys.exit(app.exec())

if __name__=="__main__":
    main()
